"""Synthetic integration fixtures (system-behavior tests ONLY, no predictive claims).

Benchmark identities differ, so these are explicit SYNTHETIC fixtures used to test
the event/state/replay machinery. Not for any predictive paper claim.
"""
from __future__ import annotations
from typing import List
from schemas.models import LearningEvent


def _ev(i, user, ts, act, correct, concept="c1", rt=20000, attempts=1, hints=0,
        src="fixture", extra=None):
    return LearningEvent(
        event_id=f"{user}-e{i}", user_id=user, timestamp=ts, activity_type=act,
        source=src, concept_id=concept, correctness=correct, response_time_ms=rt,
        attempts=attempts, hints=hints, metadata=extra or {})


def beginner() -> List[LearningEvent]:
    """New user, few exposures, low mastery."""
    u = "fx_beginner"; t = 1000.0
    return [_ev(1, u, t, "LEARN", False, rt=5000), _ev(2, u, t + 60, "PRACTICE", False),
            _ev(3, u, t + 120, "PRACTICE", True, rt=30000)]


def mastered_but_forgetting() -> List[LearningEvent]:
    """High mastery then long gap (recall decays)."""
    u = "fx_mastered_forget"; t = 1000.0
    evs = []
    for i in range(8):
        evs.append(_ev(i + 1, u, t + i * 60, "PRACTICE", True, rt=20000))
    evs.append(_ev(9, u, t + 30 * 86400, "REVIEW", False, rt=8000))
    return evs


def misconception_heavy() -> List[LearningEvent]:
    """Repeated incorrect answers -> strong misconception evidence."""
    u = "fx_misconception"; t = 1000.0
    return [_ev(1, u, t, "ASSESS", False, rt=30000), _ev(2, u, t + 60, "ASSESS", False),
            _ev(3, u, t + 120, "REMEDIATE", False, rt=25000)]


def uncertain_new_user() -> List[LearningEvent]:
    """Very few mixed responses -> high uncertainty."""
    u = "fx_uncertain"; t = 1000.0
    return [_ev(1, u, t, "ASSESS", True, rt=9000), _ev(2, u, t + 60, "ASSESS", False)]


def exam_cramming() -> List[LearningEvent]:
    """Dense recent practice before an exam date."""
    u = "fx_cramming"; t = 1000.0
    evs = []
    for i in range(6):
        evs.append(_ev(i + 1, u, t + i * 120, "PRACTICE", i % 2 == 0, rt=15000))
    return evs


ALL_FIXTURES = {
    "beginner": beginner,
    "mastered_but_forgetting": mastered_but_forgetting,
    "misconception_heavy": misconception_heavy,
    "uncertain_new_user": uncertain_new_user,
    "exam_cramming": exam_cramming,
}
