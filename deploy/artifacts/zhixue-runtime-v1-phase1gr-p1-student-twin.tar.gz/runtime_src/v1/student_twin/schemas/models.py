"""Core schemas for Student Digital Twin V1.

Missing values are represented as None (explicit UNKNOWN), never implicitly 0.
All models support deterministic to_dict / from_dict for hashing + replay.
"""
from __future__ import annotations
import json
import hashlib
from dataclasses import dataclass, field, asdict
from typing import Optional, List, Dict, Any

ACTIVITY_TYPES = ("LEARN", "PRACTICE", "ASSESS", "REVIEW", "REMEDIATE", "TUTOR")


@dataclass
class LearningEvent:
    event_id: str
    user_id: str
    timestamp: float
    activity_type: str
    source: str
    course_id: Optional[str] = None
    concept_id: Optional[str] = None
    item_id: Optional[str] = None
    question_id: Optional[str] = None
    answer: Optional[str] = None
    correctness: Optional[bool] = None
    response_time_ms: Optional[int] = None
    attempts: Optional[int] = None
    hints: Optional[int] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        assert self.event_id, "event_id required"
        assert self.user_id, "user_id required"
        assert self.activity_type in ACTIVITY_TYPES, f"invalid activity_type {self.activity_type}"

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class EvidenceState:
    observed_correctness: Optional[bool]
    expected_correctness: Optional[float]
    reliability: float
    uncertainty: float
    evidence_weight: float
    model_version: str
    timestamp: float
    guess_like_probability: Optional[float] = None
    slip_like_probability: Optional[float] = None

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class ConceptState:
    concept_id: str
    # knowledge
    mastery_probability: Optional[float] = None
    mastery_uncertainty: Optional[float] = None
    # assessment
    ability_alignment: Optional[float] = None
    assessment_uncertainty: Optional[float] = None
    # memory
    recall_probability_now: Optional[float] = None
    memory_stability: Optional[float] = None
    memory_difficulty: Optional[float] = None
    review_risk: Optional[float] = None
    recommended_review_at: Optional[float] = None
    # diagnosis
    misconception_topk: Optional[List[str]] = None
    # evidence
    exposure_count: int = 0
    reliable_evidence_count: int = 0
    recent_accuracy: Optional[float] = None
    last_evidence_reliability: Optional[float] = None
    # curriculum
    prerequisite_readiness: Optional[float] = None
    downstream_importance: Optional[float] = None
    # time
    first_seen_at: Optional[float] = None
    last_practiced_at: Optional[float] = None
    last_mastered_at: Optional[float] = None
    last_reviewed_at: Optional[float] = None
    # provenance
    state_version: str = "0"
    updated_at: float = 0.0

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "ConceptState":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


@dataclass
class StudentState:
    user_id: str
    global_ability: Optional[float] = None
    ability_uncertainty: Optional[float] = None
    concepts: Dict[str, ConceptState] = field(default_factory=dict)
    active_course: Optional[str] = None
    learning_goal: Optional[str] = None
    exam_date: Optional[float] = None
    time_budget: Optional[float] = None
    recent_activity_summary: Dict[str, Any] = field(default_factory=dict)
    model_versions: Dict[str, str] = field(default_factory=dict)
    state_generated_at: float = 0.0

    def to_dict(self) -> dict:
        return {
            "user_id": self.user_id,
            "global_ability": self.global_ability,
            "ability_uncertainty": self.ability_uncertainty,
            "concepts": {k: v.to_dict() for k, v in self.concepts.items()},
            "active_course": self.active_course,
            "learning_goal": self.learning_goal,
            "exam_date": self.exam_date,
            "time_budget": self.time_budget,
            "recent_activity_summary": self.recent_activity_summary,
            "model_versions": self.model_versions,
            "state_generated_at": self.state_generated_at,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "StudentState":
        concepts = {k: ConceptState.from_dict(v) for k, v in d.get("concepts", {}).items()}
        return cls(
            user_id=d["user_id"], global_ability=d.get("global_ability"),
            ability_uncertainty=d.get("ability_uncertainty"), concepts=concepts,
            active_course=d.get("active_course"), learning_goal=d.get("learning_goal"),
            exam_date=d.get("exam_date"), time_budget=d.get("time_budget"),
            recent_activity_summary=d.get("recent_activity_summary", {}),
            model_versions=d.get("model_versions", {}),
            state_generated_at=d.get("state_generated_at", 0.0),
        )


def state_hash(obj) -> str:
    """Deterministic SHA256 over the canonical JSON serialization."""
    if hasattr(obj, "to_dict"):
        obj = obj.to_dict()
    canon = json.dumps(obj, sort_keys=True, default=str, ensure_ascii=False)
    return hashlib.sha256(canon.encode("utf-8")).hexdigest()
