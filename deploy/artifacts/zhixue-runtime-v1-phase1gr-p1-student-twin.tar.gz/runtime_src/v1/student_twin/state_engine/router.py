"""RouterContext: stable decision-facing interface for downstream policy / routing.

This project does NOT implement the Router; it only guarantees a stable context output.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Optional, List, Dict, Any

from policies.policies import learning_need, DEFAULT_CONFIG


@dataclass
class RouterContext:
    user_id: str
    task_type: Optional[str] = None
    course: Optional[str] = None
    concept: Optional[str] = None
    mastery: Optional[float] = None
    mastery_uncertainty: Optional[float] = None
    ability: Optional[float] = None
    misconception_topk: Optional[List[str]] = None
    recall_probability: Optional[float] = None
    review_risk: Optional[float] = None
    evidence_reliability: Optional[float] = None
    learning_need: Optional[str] = None
    preferred_response_depth: Optional[str] = None
    recent_model_feedback: Optional[Dict[str, Any]] = None
    modality: Optional[str] = None
    context_length: Optional[int] = None
    account_tier: str = "FREE"  # FREE | PAID (policy decided by downstream Router)

    def to_dict(self) -> dict:
        return asdict(self)


def build_router_context(state, concept_id: Optional[str] = None,
                         config: dict = DEFAULT_CONFIG, **overrides) -> RouterContext:
    cs = state.concepts.get(concept_id) if concept_id else None
    ctx = RouterContext(
        user_id=state.user_id,
        course=state.active_course,
        concept=concept_id,
        ability=state.global_ability,
    )
    if cs is not None:
        ctx.mastery = cs.mastery_probability
        ctx.mastery_uncertainty = cs.mastery_uncertainty
        ctx.misconception_topk = cs.misconception_topk
        ctx.recall_probability = cs.recall_probability_now
        ctx.review_risk = cs.review_risk
        ctx.evidence_reliability = cs.last_evidence_reliability
        ctx.learning_need = learning_need(cs, config)
    for k, v in overrides.items():
        if hasattr(ctx, k):
            setattr(ctx, k, v)
    return ctx
