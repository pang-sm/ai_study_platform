"""Student Digital Twin state engine: reliability-weighted deterministic update + replay."""
from __future__ import annotations
import time
from typing import Optional, Dict, List, Any

from schemas.models import (
    LearningEvent, EvidenceState, ConceptState, StudentState, state_hash)
from policies.policies import learning_need, review_priority, conflict_resolution, DEFAULT_CONFIG


class StudentDigitalTwin:
    def __init__(self, store, adapters: Dict[str, Any], config: dict = None):
        self.store = store
        self.adapters = adapters
        self.config = config or DEFAULT_CONFIG
        self.alpha = 0.3  # base mastery learning rate
        self._last_ts: Dict[str, float] = {}  # per-user last processed timestamp

    # ---- update protocol ----
    def _evidence_state(self, ev: LearningEvent) -> Optional[EvidenceState]:
        ev_adapter = self.adapters.get("evidence")
        if ev_adapter is None:
            return None
        res = ev_adapter.adapt({
            "correctness": ev.correctness,
            "response_time_ms": ev.response_time_ms,
            "attempts": ev.attempts,
            "hints": ev.hints,
            "expected_correctness": None,
        })
        return EvidenceState(
            observed_correctness=ev.correctness,
            expected_correctness=None,
            reliability=res.value,
            uncertainty=res.uncertainty if res.uncertainty is not None else 0.5,
            evidence_weight=res.value if res.weight_supported else 1.0,
            model_version=res.model_version, timestamp=ev.timestamp,
        )

    def _apply_event(self, state: StudentState, ev: LearningEvent) -> None:
        cid = ev.concept_id or ev.item_id or "_global"
        cs = state.concepts.get(cid)
        if cs is None:
            cs = ConceptState(concept_id=cid, first_seen_at=ev.timestamp,
                              state_version="1", updated_at=ev.timestamp)
            state.concepts[cid] = cs

        cs.exposure_count += 1
        cs.last_practiced_at = ev.timestamp

        ev_state = self._evidence_state(ev)
        if ev_state is not None:
            cs.last_evidence_reliability = ev_state.reliability
            if ev_state.reliability >= 0.5:
                cs.reliable_evidence_count += 1
            w = ev_state.evidence_weight  # already 1.0 when WEIGHT_NOT_SUPPORTED
        else:
            w = 1.0

        if ev.correctness is not None:
            # reliability-weighted mastery update (weight applied when supported)
            if cs.mastery_probability is None:
                cs.mastery_probability = 0.5
            target = 1.0 if ev.correctness else 0.0
            delta = self.alpha * w * (target - cs.mastery_probability)
            cs.mastery_probability = max(0.0, min(1.0, cs.mastery_probability + delta))
            cs.mastery_uncertainty = max(0.05, (1.0 - w) * 0.5 + 0.05)
            # recent accuracy (rolling over last 10)
            acc = getattr(cs, "_acc_buf", [])
            acc = (acc + [int(ev.correctness)])[-10:]
            cs.recent_accuracy = sum(acc) / len(acc)
            setattr(cs, "_acc_buf", acc)

        # memory update on REVIEW activity
        if ev.activity_type == "REVIEW":
            mem = self.adapters.get("memory")
            if mem is not None:
                res = mem.adapt([{"correctness": ev.correctness, "timestamp": ev.timestamp}],
                                now=ev.timestamp)
                if res.field == "recall_probability_now":
                    cs.recall_probability_now = res.value
                    cs.review_risk = round(1.0 - res.value, 4) if res.value is not None else None
                    cs.recommended_review_at = ev.timestamp + 86400 * 30
                    cs.last_reviewed_at = ev.timestamp

        # misconception update on incorrect assessment
        if ev.correctness is False and ev.activity_type in ("ASSESS", "PRACTICE", "REMEDIATE"):
            mis = self.adapters.get("misconception")
            if mis is not None:
                res = mis.adapt({"correctness": False, "answer": ev.answer})
                cs.misconception_topk = res.value

        cs.state_version = str(int(cs.state_version) + 1)
        cs.updated_at = ev.timestamp

    def _recompute_derived(self, state: StudentState) -> None:
        graph = self.adapters.get("graph")
        for cid, cs in state.concepts.items():
            if graph is not None:
                concept_map = {k: {"mastery_probability": v.mastery_probability}
                               for k, v in state.concepts.items()}
                res = graph.adapt(cid, concept_map)
                if res.field == "prerequisite_readiness":
                    cs.prerequisite_readiness = res.value
                    cs.downstream_importance = graph._out_degree(cid)
        # global ability from recent accuracy across concepts
        mast = [c.mastery_probability for c in state.concepts.values()
                if c.mastery_probability is not None]
        if mast:
            state.global_ability = sum(mast) / len(mast)
            state.ability_uncertainty = 0.5 / max(len(mast), 1) ** 0.5

    # ---- public API ----
    def ingest_event(self, ev: LearningEvent) -> ConceptState:
        last = self._last_ts.get(ev.user_id, float("-inf"))
        if ev.timestamp < last:
            # out-of-order: do NOT silently pollute state -> full deterministic replay
            self._last_ts[ev.user_id] = max(last, ev.timestamp)
            self.replay_user(ev.user_id)
        else:
            state = self._load_or_new(ev.user_id)
            self._apply_event(state, ev)
            self._recompute_derived(state)
            state.state_generated_at = ev.timestamp
            self.store.save_student_snapshot(state, state_hash(state))
            self._last_ts[ev.user_id] = ev.timestamp
        return self.get_concept_state(ev.user_id, ev.concept_id or ev.item_id or "_global")

    def replay_user(self, user_id: str) -> str:
        """Clear derived state and deterministically re-apply all events in order."""
        events = self.store.get_events(user_id)
        state = StudentState(user_id=user_id, state_generated_at=0.0)
        for ev in events:
            self._apply_event(state, ev)
        self._recompute_derived(state)
        # deterministic: state time derived from events, NOT wall clock
        state.state_generated_at = events[-1].timestamp if events else 0.0
        self.store.save_student_snapshot(state, state_hash(state))
        return state_hash(state)

    def _load_or_new(self, user_id: str) -> StudentState:
        snap = self.store.load_student_snapshot(user_id)
        return snap if snap is not None else StudentState(user_id=user_id,
                                                          state_generated_at=time.time())

    def get_student_state(self, user_id: str) -> StudentState:
        return self._load_or_new(user_id)

    def get_concept_state(self, user_id: str, concept_id: str) -> Optional[ConceptState]:
        return self._load_or_new(user_id).concepts.get(concept_id)

    def get_learning_need(self, user_id: str, concept_id: str) -> str:
        cs = self.get_concept_state(user_id, concept_id)
        if cs is None:
            return "NEED_ASSESS"
        return learning_need(cs, self.config)

    def get_review_queue(self, user_id: str, exam_date: Optional[float] = None,
                         now: Optional[float] = None) -> List:
        now = now or time.time()
        state = self._load_or_new(user_id)
        queue = []
        for cid, cs in state.concepts.items():
            rp = review_priority(cs, self.config, now=now, exam_date=exam_date)
            queue.append(rp)
        queue.sort(key=lambda x: -x.priority_score)
        return queue

    def conflict_for(self, user_id: str, concept_id: str, evidence: Dict) -> Optional[str]:
        cs = self.get_concept_state(user_id, concept_id)
        if cs is None:
            return None
        return conflict_resolution(cs, evidence)
