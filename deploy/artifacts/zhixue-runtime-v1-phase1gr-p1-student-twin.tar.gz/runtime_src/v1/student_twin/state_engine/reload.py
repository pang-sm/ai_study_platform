"""Real-artifact smoke test + full end-to-end reload (fresh process)."""
import os
import sys
import json
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from schemas.models import LearningEvent, state_hash
from event_store.store import EventStore
from adapters.adapters import (EvidenceReliabilityAdapter, IRTAdapter, MemoryAdapter,
                               MisconceptionAdapter, KnowledgeGraphAdapter)
from state_engine.engine import StudentDigitalTwin
from state_engine.router import build_router_context
from fixtures.fixtures import ALL_FIXTURES


REAL_ARTIFACTS = {
    "evidence_reliability": "/root/autodl-tmp/evidence_reliability/checkpoints/reliability_net_42.pt",
    "irt_data": "/root/autodl-tmp/coursegraph_kt/data/processed/interactions.csv",
    "misconception_ontology": "/root/autodl-tmp/misconception_net_v2/checkpoints/final_retriever/ontology.json",
    "knowledge_graph": "/root/autodl-tmp/coursegraph_kt/data/processed/junyi/prereq_edges.csv",
    "memory_model": "/root/autodl-tmp/memory_review_engine/src/models/__init__.py",
}


def real_artifact_smoke():
    print("=== real artifact smoke test ===")
    results = {}
    # 1. evidence reliability
    a = EvidenceReliabilityAdapter(REAL_ARTIFACTS["evidence_reliability"])
    r = a.adapt({"correctness": True, "response_time_ms": 30000, "attempts": 1, "hints": 0})
    results["evidence_reliability"] = (a.artifact is not None, r.to_dict())
    # 2. IRT
    i = IRTAdapter(REAL_ARTIFACTS["irt_data"])
    r2 = i.adapt([{"correctness": True}, {"correctness": False}, {"correctness": True}])
    results["irt"] = (i.artifact is not None, r2.to_dict())
    # 3. memory
    m = MemoryAdapter(REAL_ARTIFACTS["memory_model"])
    r3 = m.adapt([{"correctness": True, "timestamp": time.time() - 86400}], now=time.time())
    results["memory"] = (True, r3.to_dict())
    # 4. misconception
    mm = MisconceptionAdapter(REAL_ARTIFACTS["misconception_ontology"])
    r4 = mm.adapt({"correctness": False, "answer": "wrong"})
    results["misconception"] = (mm.ontology is not None, r4.to_dict())
    # 5. knowledge graph
    kg = KnowledgeGraphAdapter(REAL_ARTIFACTS["knowledge_graph"])
    r5 = kg.adapt("c1", {"c0": {"mastery_probability": 0.8}})
    results["knowledge_graph"] = (kg.edges is not None, r5.to_dict())

    all_pass = all(v[0] for v in results.values())
    for k, (ok, r) in results.items():
        print(f"  {k}: load={'OK' if ok else 'FALLBACK'} -> {json.dumps(r, default=str)[:120]}")
    print(f"  ARTIFACT_INTERFACE_PASS = {'YES' if all_pass else 'PARTIAL'}")
    return all_pass


def full_reload():
    print("\n=== full reload ===")
    store = EventStore("/root/autodl-tmp/student_digital_twin/event_store/sdt.db")
    adapters = {
        "evidence": EvidenceReliabilityAdapter(REAL_ARTIFACTS["evidence_reliability"]),
        "memory": MemoryAdapter(REAL_ARTIFACTS["memory_model"]),
        "misconception": MisconceptionAdapter(REAL_ARTIFACTS["misconception_ontology"]),
        "graph": KnowledgeGraphAdapter(REAL_ARTIFACTS["knowledge_graph"]),
    }
    twin = StudentDigitalTwin(store, adapters)
    for name, fn in ALL_FIXTURES.items():
        for e in fn():
            store.append_event(e)
            twin.ingest_event(e)
    # replay one fixture user + build state/queue/context
    u = "fx_mastered_forget"
    h1 = twin.replay_user(u)
    state = twin.get_student_state(u)
    queue = twin.get_review_queue(u)
    ctx = build_router_context(state, concept_id="c1", task_type="TUTOR", account_tier="FREE")
    h2 = state_hash(state)
    print(f"  replay hash: {h1[:16]}...")
    print(f"  review queue size: {len(queue)}")
    print(f"  router context: {json.dumps(ctx.to_dict(), default=str)[:200]}")
    print(f"  DETERMINISTIC_REPLAY_PASS = {'YES' if h1 == h2 else 'NO'}")
    print(f"  FINAL_RELOAD_PASS = {'YES' if h1 == h2 and len(queue) >= 0 and ctx.mastery is not None else 'NO'}")
    store.close()


if __name__ == "__main__":
    real_artifact_smoke()
    full_reload()
