"""SQLite append-only, idempotent event store + state snapshots + model registry."""
import os
import json
import sqlite3
from typing import Optional, List

from schemas.models import LearningEvent, StudentState, ConceptState


SCHEMA = """
CREATE TABLE IF NOT EXISTS learning_events (
    event_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    timestamp REAL NOT NULL,
    activity_type TEXT NOT NULL,
    source TEXT NOT NULL,
    course_id TEXT, concept_id TEXT, item_id TEXT, question_id TEXT,
    answer TEXT, correctness INTEGER, response_time_ms INTEGER,
    attempts INTEGER, hints INTEGER, metadata TEXT
);
CREATE INDEX IF NOT EXISTS idx_events_user_time ON learning_events(user_id, timestamp);
CREATE INDEX IF NOT EXISTS idx_events_concept ON learning_events(user_id, concept_id);

CREATE TABLE IF NOT EXISTS student_state_snapshots (
    user_id TEXT PRIMARY KEY,
    state_json TEXT NOT NULL,
    state_hash TEXT NOT NULL,
    updated_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS concept_state_snapshots (
    user_id TEXT NOT NULL,
    concept_id TEXT NOT NULL,
    state_json TEXT NOT NULL,
    updated_at REAL NOT NULL,
    PRIMARY KEY (user_id, concept_id)
);
CREATE TABLE IF NOT EXISTS model_registry (
    model_name TEXT PRIMARY KEY,
    version TEXT NOT NULL,
    source TEXT,
    registered_at REAL
);
"""


class EventStore:
    def __init__(self, path: str):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self.path = path
        self.conn = sqlite3.connect(path)
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    # ---- events ----
    def append_event(self, ev: LearningEvent) -> bool:
        """Append an event. Idempotent: returns False if event_id already exists."""
        cur = self.conn.execute(
            "INSERT OR IGNORE INTO learning_events VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (ev.event_id, ev.user_id, ev.timestamp, ev.activity_type, ev.source,
             ev.course_id, ev.concept_id, ev.item_id, ev.question_id, ev.answer,
             int(ev.correctness) if ev.correctness is not None else None,
             ev.response_time_ms, ev.attempts, ev.hints,
             json.dumps(ev.metadata, sort_keys=True, default=str)))
        self.conn.commit()
        return cur.rowcount > 0

    def get_events(self, user_id: str) -> List[LearningEvent]:
        rows = self.conn.execute(
            "SELECT * FROM learning_events WHERE user_id=? ORDER BY timestamp, event_id",
            (user_id,)).fetchall()
        cols = ["event_id", "user_id", "timestamp", "activity_type", "source",
                "course_id", "concept_id", "item_id", "question_id", "answer",
                "correctness", "response_time_ms", "attempts", "hints", "metadata"]
        out = []
        for r in rows:
            d = dict(zip(cols, r))
            d["correctness"] = bool(d["correctness"]) if d["correctness"] is not None else None
            d["metadata"] = json.loads(d["metadata"]) if d["metadata"] else {}
            out.append(LearningEvent(**d))
        return out

    def count_events(self, user_id: Optional[str] = None) -> int:
        if user_id is None:
            return self.conn.execute("SELECT COUNT(*) FROM learning_events").fetchone()[0]
        return self.conn.execute("SELECT COUNT(*) FROM learning_events WHERE user_id=?",
                                 (user_id,)).fetchone()[0]

    # ---- snapshots ----
    def save_student_snapshot(self, state: StudentState, state_hash: str):
        self.conn.execute(
            "INSERT OR REPLACE INTO student_state_snapshots VALUES (?,?,?,?)",
            (state.user_id, json.dumps(state.to_dict(), sort_keys=True, default=str),
             state_hash, state.state_generated_at))
        self.conn.commit()

    def load_student_snapshot(self, user_id: str) -> Optional[StudentState]:
        r = self.conn.execute("SELECT state_json FROM student_state_snapshots WHERE user_id=?",
                              (user_id,)).fetchone()
        if r is None:
            return None
        return StudentState.from_dict(json.loads(r[0]))

    # ---- model registry ----
    def register_model(self, name: str, version: str, source: str = "", ts: float = 0.0):
        self.conn.execute("INSERT OR REPLACE INTO model_registry VALUES (?,?,?,?)",
                          (name, version, source, ts))
        self.conn.commit()

    def get_model(self, name: str) -> Optional[dict]:
        r = self.conn.execute("SELECT * FROM model_registry WHERE model_name=?",
                              (name,)).fetchone()
        if r is None:
            return None
        return {"model_name": r[0], "version": r[1], "source": r[2], "registered_at": r[3]}

    def close(self):
        self.conn.close()
