"""Interpretable policies: learning need, review priority, conflict handling.

Thresholds/weights are configurable policy parameters (NOT benchmark-optimized).
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, Dict, List
import math


DEFAULT_CONFIG = {
    "mastery_low": 0.4,
    "mastery_high": 0.8,
    "recall_low": 0.5,
    "uncertainty_high": 0.3,
    "review_risk_high": 0.5,
    "review_risk_weight": 0.30,
    "course_importance_weight": 0.20,
    "prerequisite_weight": 0.20,
    "uncertainty_weight": 0.15,
    "exam_proximity_weight": 0.15,
    "staleness_days": 30,
    "exam_proximity_days": 14,
}


def learning_need(cs, config: dict = DEFAULT_CONFIG) -> str:
    """Map a ConceptState to one of the interpretable learning-need states."""
    mast = cs.mastery_probability
    unc = cs.mastery_uncertainty
    recall = cs.recall_probability_now
    mis = cs.misconception_topk

    if mis is not None and len(mis) > 0 and (cs.recent_accuracy or 1.0) < 0.5:
        return "NEED_REMEDIATE"
    if mast is not None and mast < config["mastery_low"]:
        return "NEED_LEARN" if (cs.exposure_count or 0) <= 1 else "NEED_PRACTICE"
    if mast is not None and mast >= config["mastery_high"]:
        if recall is not None and recall < config["recall_low"]:
            return "NEED_REVIEW"
        return "READY_TO_ADVANCE"
    if unc is not None and unc > config["uncertainty_high"]:
        return "NEED_ASSESS"
    if mast is not None:
        return "NEED_PRACTICE"
    return "NEED_ASSESS"  # unknown mastery -> assess


@dataclass
class ReviewPriority:
    concept_id: str
    priority_score: float
    reason_components: Dict[str, float]
    recommended_review_at: Optional[float]


def review_priority(cs, config: dict = DEFAULT_CONFIG, now: float = 0.0,
                    exam_date: Optional[float] = None) -> ReviewPriority:
    risk = cs.review_risk if cs.review_risk is not None else 0.0
    importance = cs.downstream_importance if cs.downstream_importance is not None else 0.5
    prereq_value = (1.0 - (cs.prerequisite_readiness if cs.prerequisite_readiness is not None else 1.0))
    uncertainty = cs.mastery_uncertainty if cs.mastery_uncertainty is not None else 0.5
    exam_prox = 0.0
    if exam_date is not None and now > 0:
        days = (exam_date - now) / 86400.0
        exam_prox = max(0.0, 1.0 - days / config["exam_proximity_days"]) if days >= 0 else 1.0

    comps = {
        "review_risk": risk,
        "course_importance": importance,
        "prerequisite_value": prereq_value,
        "assessment_uncertainty": uncertainty,
        "exam_proximity": exam_prox,
    }
    w = config
    score = (w["review_risk_weight"] * risk + w["course_importance_weight"] * importance
             + w["prerequisite_weight"] * prereq_value + w["uncertainty_weight"] * uncertainty
             + w["exam_proximity_weight"] * exam_prox)
    rec_at = cs.recommended_review_at
    return ReviewPriority(concept_id=cs.concept_id, priority_score=round(score, 4),
                          reason_components=comps, recommended_review_at=rec_at)


def conflict_resolution(cs, evidence) -> Optional[str]:
    """Return an explanation string for the 5 canonical conflicts, else None."""
    mast = cs.mastery_probability
    recall = cs.recall_probability_now
    unc = cs.mastery_uncertainty
    rel = evidence.get("reliability") if evidence else None
    corr = evidence.get("observed_correctness") if evidence else None
    mis = cs.misconception_topk

    # Case A: high mastery + low recall
    if mast is not None and recall is not None and mast >= 0.8 and recall < 0.5:
        return "LEARNED_BUT_FORGETTING -> REVIEW"
    # Case B: low mastery + high recall
    if mast is not None and recall is not None and mast < 0.4 and recall >= 0.7:
        return "RECENTLY_EXPOSED_NOT_DEEPLY_LEARNED"
    # Case C: medium mastery + high uncertainty
    if mast is not None and unc is not None and 0.4 <= mast <= 0.8 and unc > 0.3:
        return "HIGH_UNCERTAINTY -> ASSESS"
    # Case D: correct + low reliability
    if corr is True and rel is not None and rel < 0.5:
        return "WEAK_POSITIVE_EVIDENCE"
    # Case E: incorrect + strong misconception
    if corr is False and mis is not None and len(mis) > 0:
        return "STRONG_MISCONCEPTION -> REMEDIATE"
    return None
