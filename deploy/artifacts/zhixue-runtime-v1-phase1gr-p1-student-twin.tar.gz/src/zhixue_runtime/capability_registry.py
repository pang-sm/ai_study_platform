"""Unified 13-component scientific runtime capability registry (Phase 1G release freeze).

This is the SINGLE frozen source of truth for how a future Backend may safely use each
scientific component — WITHOUT importing torch/transformers/faiss or reading the research
source.  It is derived from the verified facts established across Phase 1D/1F/1G; it is
NOT a second registry, and it does NOT duplicate RUNTIME_COMPONENT_MANIFEST.json (which
remains the static historical baseline).

Key invariant: ``controls_product_decision = False`` for ALL 13 components.  Native PASS
does NOT mean product ACTIVE.
"""
from .components.adapters import ADAPTERS, get_adapter as _get_adapter

# --------------------------------------------------------------------------- #
# frozen per-component capability metadata (verified facts, not re-derived)
# --------------------------------------------------------------------------- #
COMPONENT_CAPABILITIES = {
    "domestic_registry": {
        "component_id": "domestic_registry",
        "runtime_status": "FRESH_NATIVE_PASS",
        "source_class": "ORIGINAL_ARCHIVE_VERIFIED",
        "scientific_task": "domestic model registry JSON metadata access (no scientific inference)",
        "native_verified": True, "fresh_process_verified": True,
        "product_role": "DATA_PRODUCER", "controls_product_decision": False, "shadow_candidate": False,
        "variant_mode": "NONE", "active_product_variant": None,
        "replacement_readiness": "COLLECTING_DATA",
        "heavy": False, "offline_safe": True,
        "score_semantics": "NOT_APPLICABLE",
        "weak_label_semantics": "NOT_APPLICABLE",
        "scientific_ontology": "domestic model registry", "product_ontology_relation": "N/A",
        "data_producer_contract": ["provider", "capability", "model_id", "deployment_type", "cost"],
        "dependencies": [],
        "provenance": {"source_repo": "domestic_model_pool"},
    },
    "difficulty_prior": {
        "component_id": "difficulty_prior",
        "runtime_status": "FRESH_NATIVE_PASS",
        "source_class": "ORIGINAL_ARCHIVE_VERIFIED",
        "scientific_task": "1024-d BGE-M3 embedding -> difficulty (sklearn Ridge.predict)",
        "native_verified": True, "fresh_process_verified": True,
        "product_role": "DATA_PRODUCER", "controls_product_decision": False, "shadow_candidate": False,
        "variant_mode": "NONE", "active_product_variant": None,
        "replacement_readiness": "COLLECTING_DATA",
        "heavy": False, "offline_safe": True,
        "score_semantics": "difficulty score (Ridge prediction; NOT probability)",
        "weak_label_semantics": "NOT_APPLICABLE",
        "scientific_ontology": "BGE-M3 1024-d embedding (NOT raw question text)",
        "product_ontology_relation": "PARTIAL (embedding-interface compatible)",
        "data_producer_contract": ["question_ref", "embedding", "difficulty", "actual_difficulty_outcome"],
        "dependencies": ["BGE-M3 embedding (upstream, pre-computed)"],
        "provenance": {"source_repo": "question_quality_engine"},
    },
    "memory": {
        "component_id": "memory",
        "runtime_status": "FRESH_NATIVE_PASS",
        "source_class": "RECONSTRUCTED_VERIFIED (FAITHFUL_MECHANICAL_EXTRACTION)",
        "scientific_task": "review-history features -> calibrated_recall_probability (MemNet + Platt)",
        "native_verified": True, "fresh_process_verified": True,
        "product_role": "DATA_PRODUCER", "controls_product_decision": False, "shadow_candidate": False,
        "variant_mode": "NONE", "active_product_variant": None,
        "replacement_readiness": "COLLECTING_DATA",
        "heavy": False, "offline_safe": True,
        "score_semantics": "calibrated_recall_probability (Platt-sigmoid)",
        "weak_label_semantics": "NOT_APPLICABLE",
        "scientific_ontology": "review-history features (log_dt, hist_len, mean_interval, mean_rating, last_rating, lapses)",
        "product_ontology_relation": "DIFFERENT",
        "data_producer_contract": ["review_event", "recall_probability", "actual_review_outcome"],
        "dependencies": ["review-history features (NOT ordinary answer events)"],
        "provenance": {"source_repo": "memory_review_engine"},
    },
    "irt": {
        "component_id": "irt",
        "runtime_status": "FRESH_NATIVE_PASS",
        "source_class": "RECONSTRUCTED_VERIFIED",
        "scientific_task": "online learner ability update under fixed 1PL item difficulty",
        "update_rule": "theta += correct - sigmoid(theta - b_item)   (provenance only; NOT an executable copy)",
        "input": ["item_id", "current_theta", "correctness"],
        "intermediate": "p_correct = sigmoid(theta - b_item)",
        "output": ["updated_theta", "predicted_correctness_probability"],
        "native_verified": True, "fresh_process_verified": True,
        "product_role": "DATA_PRODUCER", "controls_product_decision": False, "shadow_candidate": False,
        "variant_mode": "NONE", "active_product_variant": None,
        "replacement_readiness": "COLLECTING_DATA",
        "heavy": False, "offline_safe": True,
        "score_semantics": "updated_theta + p_correct (NOT mastery_probability)",
        "weak_label_semantics": "NOT_APPLICABLE",
        "scientific_ontology": "Junyi item IDs (product item IDs NOT directly usable)",
        "product_ontology_relation": "DIFFERENT",
        "data_producer_contract": ["item_id", "theta", "correct", "theta_updated", "p_correct"],
        "dependencies": ["item_parameters.parquet (Junyi)"],
        "provenance": {"source_repo": "adaptive_assessment"},
    },
    "tutor_guard": {
        "component_id": "tutor_guard",
        "runtime_status": "FRESH_NATIVE_PASS",
        "source_class": "ORIGINAL_ARCHIVE_VERIFIED",
        "scientific_task": "candidate pool -> reveal detector + ActionRecognizer compliance -> best-of-N selection",
        "native_verified": True, "fresh_process_verified": True,
        "product_role": "DATA_PRODUCER", "controls_product_decision": False, "shadow_candidate": False,
        "variant_mode": "NONE", "active_product_variant": None,
        "replacement_readiness": "COLLECTING_DATA",
        "heavy": True, "offline_safe": True,
        "score_semantics": "reveal (0/1) + compliance_score (softmax P(action)); selected candidate",
        "weak_label_semantics": "NOT_APPLICABLE (scientific guard recommendation, NOT ALLOW/REJECT)",
        "scientific_ontology": "4-action ontology (focus/generic/probing/telling)",
        "product_ontology_relation": "N/A",
        "data_producer_contract": ["policy_requested_action", "policy_action_probabilities", "generated_response",
                                   "guard_observed_action", "guard_compliance_score", "guard_reveal_score",
                                   "policy_guard_agreement", "learner_response", "immediate_correctness", "later_mastery"],
        "dependencies": ["frozen candidate pool", "ActionRecognizer (BGE-M3, self-contained)"],
        "provenance": {"source_repo": "tutor_guard / edututor"},
    },
    "planner": {
        "component_id": "planner",
        "runtime_status": "FRESH_NATIVE_PASS",
        "source_class": "ORIGINAL_ARCHIVE_VERIFIED",
        "scientific_task": "mastered + difficulty -> graph-greedy selected node",
        "native_verified": True, "fresh_process_verified": True,
        "product_role": "DATA_PRODUCER", "controls_product_decision": False, "shadow_candidate": False,
        "variant_mode": "NONE", "active_product_variant": None,
        "replacement_readiness": "COLLECTING_DATA",
        "heavy": False, "offline_safe": True,
        "score_semantics": "pcorr*(1-pcorr) uncertainty score",
        "weak_label_semantics": "NOT_APPLICABLE",
        "scientific_ontology": "RESEARCH_JUNYI_GRAPH (minimal schema-valid fixture; real edges NOT bundled)",
        "product_ontology_relation": "DIFFERENT",
        "data_producer_contract": ["scientific_candidates", "scientific_selected_node", "scientific_scores",
                                   "actual_product_selected_node", "learner_followed_recommendation", "subsequent_learning_outcome"],
        "dependencies": ["prerequisite graph (research Junyi)"],
        "provenance": {"source_repo": "learning_planner"},
    },
    "execution_router": {
        "component_id": "execution_router",
        "runtime_status": "FRESH_NATIVE_PASS",
        "source_class": "ORIGINAL_ARCHIVE_VERIFIED",
        "scientific_task": "task -> route decision (q0/q1 quality + registry cost -> argmax/argmin)",
        "native_verified": True, "fresh_process_verified": True,
        "product_role": "DATA_PRODUCER", "controls_product_decision": False, "shadow_candidate": False,
        "variant_mode": "NONE", "active_product_variant": None,
        "replacement_readiness": "COLLECTING_DATA",
        "heavy": False, "offline_safe": True,
        "score_semantics": "routing score (q1/cost/utility) — NOT provider execution",
        "weak_label_semantics": "NOT_APPLICABLE",
        "scientific_ontology": "model registry (45 models)",
        "product_ontology_relation": "N/A",
        "data_producer_contract": ["scientific_route", "actual_route", "latency", "cost", "quality", "success_outcome"],
        "dependencies": ["model_registry.json (bundled)"],
        "provenance": {"source_repo": "execution_router"},
    },
    "concept_verifier": {
        "component_id": "concept_verifier",
        "runtime_status": "FRESH_NATIVE_PASS",
        "source_class": "ORIGINAL_ARCHIVE_VERIFIED",
        "scientific_task": "question+concept -> P(aligned) [SUPPORTED]; question+answer -> P(correct) [NOT_SUPPORTED]",
        "native_verified": True, "fresh_process_verified": True,
        "product_role": "DATA_PRODUCER", "controls_product_decision": False,
        "shadow_candidate": True,  # concept_alignment capability only
        "variant_mode": "NONE", "active_product_variant": None,
        "replacement_readiness": "COLLECTING_DATA",
        "heavy": True, "offline_safe": True,
        "score_semantics": "P(class 1) = softmax(logits)[1]; scientific_threshold NONE (0.5 = ENGINEERING_DEFAULT)",
        "weak_label_semantics": "NOT_APPLICABLE",
        "scientific_ontology": "Eedi English math (concept_alignment AUROC 0.828; answer_consistency AUROC 0.502 NOT_SUPPORTED)",
        "product_ontology_relation": "DIFFERENT",
        "data_producer_contract": ["question_ref", "concept_ref", "answer_hash", "verification_score", "predicted_label",
                                   "actual_product_decision", "human_or_outcome_label", "eventual_learning_outcome"],
        "dependencies": ["DeBERTa-v3 (2 heads, self-contained)"],
        "provenance": {"source_repo": "question_quality_engine"},
    },
    "tutor_policy": {
        "component_id": "tutor_policy",
        "runtime_status": "FRESH_NATIVE_PASS",
        "source_class": "ORIGINAL_ARCHIVE_VERIFIED",
        "scientific_task": "FULL_STATE -> P(action) (4-way action classification)",
        "native_verified": True, "fresh_process_verified": True,
        "product_role": "DATA_PRODUCER", "controls_product_decision": False, "shadow_candidate": False,
        "variant_mode": "NONE", "active_product_variant": None,
        "replacement_readiness": "COLLECTING_DATA",
        "heavy": True, "offline_safe": True,
        "score_semantics": "action_probabilities (softmax over focus/generic/probing/telling)",
        "weak_label_semantics": "NOT_APPLICABLE",
        "scientific_ontology": "4-action ontology (EXACT match with TutorGuard; 0=focus 1=generic 2=probing 3=telling)",
        "product_ontology_relation": "N/A",
        "data_producer_contract": ["policy_requested_action", "policy_action_probabilities", "generated_response",
                                   "guard_observed_action", "policy_guard_agreement", "learner_response", "later_mastery"],
        "dependencies": ["BGE-M3 (self-contained)"],
        "provenance": {"source_repo": "tutor_policy"},
    },
    "misconception_v2": {
        "component_id": "misconception_v2",
        "runtime_status": "FRESH_NATIVE_PASS",
        "source_class": "ORIGINAL_ARCHIVE_VERIFIED",
        "scientific_task": "question+answer -> top-k misconception (dual-encoder + FAISS IndexFlatIP)",
        "native_verified": True, "fresh_process_verified": True,
        "product_role": "DATA_PRODUCER", "controls_product_decision": False, "shadow_candidate": False,
        "variant_mode": "NONE", "active_product_variant": None,
        "replacement_readiness": "COLLECTING_DATA",
        "heavy": True, "offline_safe": True,
        "score_semantics": "cosine-like normalized inner product (NOT probability)",
        "weak_label_semantics": True,  # retrieved misconception = WEAK label, not ground truth
        "scientific_ontology": "Eedi English math (2587 misconceptions)",
        "product_ontology_relation": "DIFFERENT",
        "data_producer_contract": ["question_reference", "answer_hash", "retrieved_misconception_ids", "retrieval_scores",
                                   "ranking", "actual_teacher_or_rule_label", "later_correction", "subsequent_retry_result", "later_mastery"],
        "dependencies": ["BGE-M3 (self-contained)", "faiss-cpu 1.15.0 IndexFlatIP (index.faiss bundled)"],
        "provenance": {"source_repo": "misconception_net_v2"},
    },
    "evidence_reliability": {
        "component_id": "evidence_reliability",
        "runtime_status": "FRESH_NATIVE_PASS",
        "source_class": "ORIGINAL_ARCHIVE_VERIFIED",
        "scientific_task": "interaction features -> reliability weight w (reliability-weighted learner update)",
        "native_verified": True, "fresh_process_verified": True,
        "product_role": "DATA_PRODUCER", "controls_product_decision": False, "shadow_candidate": False,
        "variant_mode": "PANEL", "active_product_variant": None,
        "replacement_readiness": "COLLECTING_DATA",
        "heavy": False, "offline_safe": True,
        "score_semantics": "reliability weight w in (0,1) — NOT P(correct)",
        "weak_label_semantics": "NOT_APPLICABLE",
        "scientific_ontology": "ASSISTments (base 123 skills)",
        "product_ontology_relation": "DIFFERENT",
        "data_producer_contract": ["evidence_reference", "variant_id", "reliability_score",
                                   "variant_disagreement", "human_or_manual_reliability_label", "downstream_correctness", "later_outcome"],
        "dependencies": ["small MLP (5 checkpoints, self-contained)"],
        "provenance": {"source_repo": "evidence_reliability"},
    },
    "learner_state": {
        "component_id": "learner_state",
        "runtime_status": "FRESH_NATIVE_PASS",
        "source_class": "ORIGINAL_ARCHIVE_VERIFIED",
        "scientific_task": "interaction sequence -> next_response_probability (knowledge tracing)",
        "native_verified": True, "fresh_process_verified": True,
        "product_role": "DATA_PRODUCER", "controls_product_decision": False, "shadow_candidate": False,
        "variant_mode": "PANEL", "active_product_variant": None,
        "replacement_readiness": "COLLECTING_DATA",
        "heavy": False, "offline_safe": True,
        "score_semantics": "next_response_probability P(correct) — NOT mastery_probability",
        "weak_label_semantics": "NOT_APPLICABLE",
        "scientific_ontology": "ASSISTments (base 123 skills) + Junyi (junyi 835 concepts)",
        "product_ontology_relation": "DIFFERENT",
        "data_producer_contract": ["user_ref", "concept_id", "sequence_position", "correctness",
                                   "scientific_family", "next_response_score", "actual_next_correctness", "later_mastery_proxy"],
        "dependencies": ["39 checkpoints across 5 families (DKT/SimpleKT/AKT/CGKT/CGKT_v2)"],
        "provenance": {"source_repo": "coursegraph_kt"},
    },
    "student_twin": {
        "component_id": "student_twin",
        "runtime_status": "FRESH_NATIVE_PASS",
        "source_class": "ORIGINAL_ARCHIVE_VERIFIED",
        "scientific_task": "LearningEvent -> StudentState (rule-based deterministic twin state engine)",
        "native_verified": True, "fresh_process_verified": True,
        "product_role": "DATA_PRODUCER", "controls_product_decision": False, "shadow_candidate": False,
        "variant_mode": "NONE", "active_product_variant": None,
        "replacement_readiness": "COLLECTING_DATA",
        "heavy": False, "offline_safe": True,
        "score_semantics": "deterministic twin state (mastery/recall/reliability/misconception/prereq)",
        "weak_label_semantics": "NOT_APPLICABLE",
        "scientific_ontology": "opaque concept_id (scientific KG NOT bundled)",
        "product_ontology_relation": "DIFFERENT",
        "data_producer_contract": ["event_id", "user_ref", "timestamp", "scientific_twin_state",
                                   "upstream_observations", "actual_next_behavior", "actual_next_correctness",
                                   "review_outcome", "later_learning_outcome"],
        "dependencies": ["rule-based engine with HEURISTIC in-tree adapters (NOT real upstream model calls)"],
        "provenance": {"source_repo": "student_digital_twin"},
    },
}

# heavy transformer components (heavy_model_slots = 1)
HEAVY_COMPONENTS = ["tutor_guard", "concept_verifier", "tutor_policy", "misconception_v2"]

# panel components (variant_mode = PANEL, no active selection)
PANEL_COMPONENTS = ["evidence_reliability", "learner_state"]


def list_components():
    return sorted(ADAPTERS.keys())


def get_capability(component_id: str) -> dict:
    if component_id not in COMPONENT_CAPABILITIES:
        raise KeyError(f"unknown component {component_id!r}")
    return COMPONENT_CAPABILITIES[component_id]


def get_adapter(component_id: str):
    return _get_adapter(component_id)


def list_heavy():
    return list(HEAVY_COMPONENTS)


def list_panels():
    return list(PANEL_COMPONENTS)


def product_role_summary():
    roles = {}
    for cid in list_components():
        cap = get_capability(cid)
        roles[cap["product_role"]] = roles.get(cap["product_role"], 0) + 1
    return roles
