"""zhixue_runtime — lightweight engineering runtime layer.

Importing this package MUST NOT load torch/transformers/faiss/numpy/pandas,
must not read files, must not open the network.

Heavy model loading happens only inside ComponentLoader implementations
(Phase 1F), never at import time.
"""
from .version import __version__
from .config import RuntimeConfig
from .errors import (
    ZhixueRuntimeError, ConfigurationError, ManifestError, ComponentNotFoundError,
    ComponentNotReadyError, VariantUnresolvedError, OptionalDependencyMissingError,
    AssetMissingError, SourceMissingError, ModelLoadError, InferenceError,
    ProductIncompatibleError, LoaderNotImplemented,
)
from .enums import ContractStatus, ProductEligibility, RecommendedMode, NativeVerification
from .registry import ComponentRegistry
from .resolver import ResourceResolver
from .capability import CapabilityReport

__all__ = [
    "__version__", "RuntimeConfig",
    "ZhixueRuntimeError", "ConfigurationError", "ManifestError", "ComponentNotFoundError",
    "ComponentNotReadyError", "VariantUnresolvedError", "OptionalDependencyMissingError",
    "AssetMissingError", "SourceMissingError", "ModelLoadError", "InferenceError",
    "ProductIncompatibleError", "LoaderNotImplemented",
    "ContractStatus", "ProductEligibility", "RecommendedMode", "NativeVerification",
    "ComponentRegistry", "ResourceResolver", "CapabilityReport",
]
