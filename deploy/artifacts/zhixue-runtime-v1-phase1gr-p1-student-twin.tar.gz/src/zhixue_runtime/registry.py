import json
from dataclasses import dataclass, field
from typing import Dict, List, Optional
from .errors import ManifestError, ComponentNotFoundError, ConfigurationError
from .enums import ContractStatus, ProductEligibility, RecommendedMode, NativeVerification
from .config import RuntimeConfig

def _normalize_product_eligibility(v):
    m = {"SHADOW": "SHADOW_ONLY"}
    return m.get(v, v)

def _normalize_mode(v):
    return v

def _normalize_native_verification(v):
    m = {"native": "HISTORICAL_PASS"}
    return m.get(v, v)

EXPECTED_COMPONENT_IDS = [
    "concept_verifier", "difficulty_prior", "misconception_v2", "tutor_policy",
    "tutor_guard", "memory", "irt", "planner", "student_twin", "execution_router",
    "domestic_registry", "evidence_reliability", "learner_state",
]

@dataclass
class ComponentSpec:
    component_id: str
    source: dict
    assets: dict
    base_model: dict
    scientific: dict
    runtime: dict
    integration: dict
    blockers: List[str] = field(default_factory=list)

    @property
    def contract_status(self): return ContractStatus(self.scientific.get("contract_status", "UNRESOLVED"))
    @property
    def product_eligibility(self): return ProductEligibility(_normalize_product_eligibility(self.integration.get("product_eligibility", "UNRESOLVED")))
    @property
    def recommended_mode(self): return RecommendedMode(_normalize_mode(self.integration.get("recommended_mode", "DEFER")))
    @property
    def native_verification(self): return NativeVerification(_normalize_native_verification(self.integration.get("native_verification", "NOT_YET")))
    @property
    def default_variant(self): return self.scientific.get("default_variant")
    @property
    def asset_path(self): return self.assets.get("path")

class ComponentRegistry:
    def __init__(self, specs: Dict[str, ComponentSpec], manifest_path: str):
        self._specs = specs
        self.manifest_path = manifest_path

    @classmethod
    def from_home(cls, config: RuntimeConfig):
        path = config.component_manifest_path
        try:
            with open(path, encoding="utf-8") as f:
                raw = json.load(f)
        except FileNotFoundError:
            raise ManifestError(f"component manifest not found: {path}")
        components = raw.get("components", [])
        specs = {}
        for c in components:
            cid = c.get("component_id")
            if not cid:
                raise ManifestError("component entry missing component_id")
            if cid in specs:
                raise ManifestError(f"duplicate component_id: {cid}")
            specs[cid] = ComponentSpec(
                component_id=cid, source=c.get("source", {}), assets=c.get("assets", {}),
                base_model=c.get("base_model", {}), scientific=c.get("scientific", {}),
                runtime=c.get("runtime", {}), integration=c.get("integration", {}),
                blockers=c.get("blockers", []),
            )
        return cls(specs, path)

    def list_components(self) -> List[str]:
        return sorted(self._specs.keys())

    def get(self, component_id: str) -> ComponentSpec:
        if component_id not in self._specs:
            raise ComponentNotFoundError(f"component not registered: {component_id}")
        return self._specs[component_id]

    def validate(self):
        ids = set(self._specs.keys())
        missing = [x for x in EXPECTED_COMPONENT_IDS if x not in ids]
        unexpected = [x for x in ids if x not in EXPECTED_COMPONENT_IDS]
        if missing or unexpected:
            raise ManifestError(f"registry invalid: missing={missing} unexpected={unexpected}")
        for cid, spec in self._specs.items():
            _ = spec.contract_status, spec.product_eligibility, spec.recommended_mode, spec.native_verification
        return {"registered": len(ids), "unique": len(ids), "missing": missing, "unexpected": unexpected}

    def __len__(self):
        return len(self._specs)
