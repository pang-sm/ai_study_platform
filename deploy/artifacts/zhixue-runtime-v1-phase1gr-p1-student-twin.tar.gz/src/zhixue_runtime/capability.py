from typing import Dict
from .registry import ComponentRegistry
from .resolver import ResourceResolver
from .config import RuntimeConfig
from .enums import NativeVerification
import importlib.util

OPTIONAL_DEPS = ["torch", "transformers", "numpy", "pandas", "sklearn", "faiss"]

def _dep_available(name: str) -> bool:
    try:
        return importlib.util.find_spec(name) is not None
    except Exception:
        return False

class CapabilityReport:
    def __init__(self, config: RuntimeConfig):
        self.config = config
        self.registry = ComponentRegistry.from_home(config)
        self.resolver = ResourceResolver(config.require_home())

    def dependency_status(self) -> Dict[str, bool]:
        return {d: _dep_available(d) for d in OPTIONAL_DEPS}

    def report(self) -> list:
        deps = self.dependency_status()
        rows = []
        for cid in self.registry.list_components():
            spec = self.registry.get(cid)
            source_resolved = True
            assets_resolved = True
            loadable = True
            blockers = list(spec.blockers)
            if spec.native_verification == NativeVerification.DEPENDENCY_BLOCKED:
                loadable = False
            if spec.scientific.get("default_variant") is None and spec.scientific.get("contract_status") in ("UNRESOLVED", "PARTIAL"):
                if cid in ("learner_state", "evidence_reliability"):
                    loadable = False
                    blockers.append("default variant unresolved")
            # dynamic faiss dependency: misconception_v2 requires faiss at inference time
            if cid == "misconception_v2" and not deps.get("faiss"):
                loadable = False
                if "faiss-cpu missing" not in blockers:
                    blockers.append("faiss-cpu missing")
            if any("faiss" in b.lower() for b in blockers):
                loadable = False
            rows.append({
                "component_id": cid,
                "registered": True,
                "source_resolved": source_resolved,
                "assets_resolved": assets_resolved,
                "base_model_resolved": spec.base_model.get("path") is None,
                "contract_status": spec.contract_status.value,
                "product_eligibility": spec.product_eligibility.value,
                "recommended_mode": spec.recommended_mode.value,
                "native_verification": spec.native_verification.value,
                "dependency_status": "missing" if any(d in blockers for d in ("faiss-cpu",)) else "ok",
                "loaded": False,
                "loadable_now": loadable,
                "blockers": blockers,
            })
        return rows
