import os
from .errors import ConfigurationError, SourceMissingError, AssetMissingError

class ResourceResolver:
    """Resolve manifest-relative paths to absolute, rejecting traversal/absolute paths."""
    def __init__(self, home: str):
        if not home:
            raise ConfigurationError("ZHIXUE_HOME is empty")
        self.home = os.path.abspath(home)

    def _resolve(self, rel: str, kind: str) -> str:
        if not rel:
            raise ConfigurationError(f"{kind} path is empty")
        r = rel.replace("\\", "/").replace("\\", "/")
        if r.startswith("/") or (len(r) > 1 and r[1] == ":"):
            raise ConfigurationError(f"{kind} path must be relative: {rel!r}")
        abs_p = os.path.abspath(os.path.join(self.home, rel.replace("/", os.sep)))
        home_p = self.home + os.sep
        if not (abs_p == self.home or abs_p.startswith(home_p)):
            raise ConfigurationError(f"{kind} path escapes home: {rel!r}")
        return abs_p

    def resolve_source(self, rel: str) -> str:
        p = self._resolve(rel, "source")
        if not os.path.exists(p):
            raise SourceMissingError(f"source missing: {rel}")
        return p

    def resolve_asset(self, rel: str) -> str:
        p = self._resolve(rel, "asset")
        if not os.path.exists(p):
            raise AssetMissingError(f"asset missing: {rel}")
        return p

    def resolve_base_model(self, rel: str) -> str:
        return self._resolve(rel, "base_model")
