import os
from dataclasses import dataclass, field

@dataclass
class RuntimeConfig:
    home: str = None
    device: str = "cpu"
    offline: bool = True
    heavy_model_slots: int = 1

    def __post_init__(self):
        # Import must not fail without ZHIXUE_HOME. Only resolve when a method
        # needs a real filesystem path.
        if self.home is None:
            self.home = os.environ.get("ZHIXUE_HOME") or None

    @property
    def has_home(self) -> bool:
        return bool(self.home)

    def require_home(self) -> str:
        if not self.home:
            raise ConfigurationError("ZHIXUE_HOME is not set")
        return self.home

    @property
    def runtime_source_root(self):
        return os.path.join(self.require_home(), "runtime_src", "v1")

    @property
    def model_asset_root(self):
        return os.path.join(self.require_home(), "model_assets", "v1")

    @property
    def base_model_root(self):
        return os.path.join(self.require_home(), "base_models")

    @property
    def component_manifest_path(self):
        return os.path.join(self.runtime_source_root, "RUNTIME_COMPONENT_MANIFEST.json")
