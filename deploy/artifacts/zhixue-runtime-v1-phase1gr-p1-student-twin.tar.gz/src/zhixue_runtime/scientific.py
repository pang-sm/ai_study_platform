import os, ast, hashlib
from .errors import ZhixueRuntimeError

class SourceVerificationError(ZhixueRuntimeError): ...
class ScientificSourceExtractor:
    """Load scientific classes from runtime_src (single source of truth) via AST, without copying source into the package."""

    def __init__(self, source_root: str):
        self.source_root = os.path.abspath(source_root)

    def _read_verified(self, rel_path: str, expected_sha: str = None):
        p = os.path.join(self.source_root, rel_path.replace("/", os.sep))
        if not os.path.exists(p):
            raise SourceVerificationError(f"scientific source missing: {rel_path}")
        with open(p, "rb") as f:
            content = f.read()
        actual = hashlib.sha256(content).hexdigest()
        if expected_sha and actual != expected_sha:
            raise SourceVerificationError(f"source SHA256 mismatch for {rel_path}: expected {expected_sha[:12]} got {actual[:12]}")
        return p, content.decode("utf-8"), actual

    def extract_class(self, rel_path: str, class_name: str, expected_sha: str = None, namespace: dict = None):
        """AST-locate a ClassDef (possibly nested inside a function) and exec it in the given namespace."""
        p, src, actual_sha = self._read_verified(rel_path, expected_sha)
        tree = ast.parse(src)
        target = None
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef) and node.name == class_name:
                target = node
                break
        if target is None:
            raise SourceVerificationError(f"class {class_name} not found in {rel_path}")
        mod = ast.Module(body=[target], type_ignores=[])
        ast.fix_missing_locations(mod)
        code = compile(mod, p, "exec")
        if namespace is None:
            import torch, torch.nn as nn
            cols = ["log_dt", "hist_len", "mean_interval", "mean_rating", "last_rating", "lapses"]
            namespace = {"torch": torch, "nn": nn, "cols": cols}
        exec(code, namespace)
        return namespace[class_name], {"source_path": rel_path, "source_sha256": actual_sha,
                                       "class_name": class_name, "lineno": target.lineno}

    def extract_symbols(self, specs, namespace: dict = None):
        """Extract named ClassDef/FunctionDef symbols from MULTIPLE files into a shared namespace.

        specs = [(rel_path, [symbol_names]), ...].  Used when a model class depends on
        helper classes/functions defined in sibling files (e.g. learner_state models import
        from .common / .gcn).  All symbols are exec'd in ONE namespace so they can reference
        each other, keeping the scientific logic in runtime_src as the single source of truth.
        """
        namespace = namespace if namespace is not None else {}
        nodes = []
        prov = {"symbols": {}, "shas": {}, "linenos": {}}
        for rel_path, names in specs:
            p, src, actual_sha = self._read_verified(rel_path)
            tree = ast.parse(src)
            for name in names:
                node = None
                for n in ast.walk(tree):
                    if isinstance(n, (ast.ClassDef, ast.FunctionDef)) and n.name == name:
                        node = n
                        break
                    if (isinstance(n, ast.Assign) and len(n.targets) == 1
                            and isinstance(n.targets[0], ast.Name) and n.targets[0].id == name):
                        node = n
                        break
                if node is None:
                    raise SourceVerificationError(f"symbol {name} not found in {rel_path}")
                nodes.append(node)
                prov["symbols"][name] = rel_path
                prov["shas"][name] = actual_sha
                prov["linenos"][name] = node.lineno
        mod = ast.Module(body=nodes, type_ignores=[])
        ast.fix_missing_locations(mod)
        code = compile(mod, "<extracted>", "exec")
        exec(code, namespace)
        return namespace, prov

    def extract_functions(self, rel_path: str, names, expected_sha: str = None):
        """AST-locate named FunctionDefs (top-level OR nested) and exec them in a shared namespace.

        The returned namespace is the functions' ``globals``: the caller may insert any
        free variables the functions reference (e.g. ``adj``/``mastered``/``difficulty`` for
        the planner, ``q0``/``q1_map``/``COST``/``pd`` for the router) before calling them.
        This keeps the scientific logic in runtime_src as the single source of truth.
        """
        p, src, actual_sha = self._read_verified(rel_path, expected_sha)
        tree = ast.parse(src)
        found = {}
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name in names and node.name not in found:
                found[node.name] = node
        missing = [n for n in names if n not in found]
        if missing:
            raise SourceVerificationError(f"functions {missing} not found in {rel_path}")
        body = [found[n] for n in names]
        mod = ast.Module(body=body, type_ignores=[])
        ast.fix_missing_locations(mod)
        code = compile(mod, p, "exec")
        ns = {}
        exec(code, ns)
        return {n: ns[n] for n in names}, ns, {
            "source_path": rel_path, "source_sha256": actual_sha,
            "functions": names, "linenos": {n: found[n].lineno for n in names},
        }
