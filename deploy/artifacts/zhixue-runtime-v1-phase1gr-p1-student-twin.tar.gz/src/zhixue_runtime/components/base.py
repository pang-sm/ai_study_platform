from typing import Protocol
from ..errors import LoaderNotImplemented

class ComponentLoader(Protocol):
    def load(self): ...
    def infer(self, *args, **kwargs): ...

class UnimplementedNativeLoader:
    def __init__(self, component_id: str):
        self.component_id = component_id
    def load(self):
        raise LoaderNotImplemented(f"native loader for {self.component_id} is not implemented (Phase 1F)")
