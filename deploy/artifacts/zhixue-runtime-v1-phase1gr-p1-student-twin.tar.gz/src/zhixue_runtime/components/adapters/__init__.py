"""Native adapter registry — LAZY per-component import (engineering patch P1).

Importing this package no longer imports any scientific adapter module, so it pulls in no
heavy third-party dependency (torch / transformers / faiss / pandas / numpy) at import
time.  ``get_adapter`` imports only the requested adapter's module on first use.

This is ``ENGINEERING_PACKAGING_ONLY``: the same adapter classes, the same component_id
mapping, and the same scientific semantics are preserved.  No scientific formula, model
behavior, source file, or asset is changed.
"""
import importlib

# component_id -> adapter class name.  The keys are the frozen 13-component registry.
# Values are the module-level class names and are intentionally NOT imported here.
_ADAPTER_CLASS = {
    "domestic_registry": "DomesticRegistryAdapter",
    "difficulty_prior": "DifficultyPriorAdapter",
    "memory": "MemoryAdapter",
    "irt": "IRTAdapter",
    "tutor_guard": "TutorGuardAdapter",
    "planner": "PlannerAdapter",
    "execution_router": "ExecutionRouterAdapter",
    "concept_verifier": "ConceptVerifierAdapter",
    "tutor_policy": "TutorPolicyAdapter",
    "misconception_v2": "MisconceptionV2Adapter",
    "evidence_reliability": "EvidenceReliabilityAdapter",
    "learner_state": "LearnerStateAdapter",
    "student_twin": "StudentTwinAdapter",
}

# Frozen registry keys (13).  Consumers use ``.keys()`` for component listing; the
# adapter classes are resolved lazily via ``get_adapter``.
ADAPTERS = dict(_ADAPTER_CLASS)


def get_adapter(component_id):
    if component_id not in _ADAPTER_CLASS:
        raise ImportError(f"native adapter not implemented for {component_id}")
    mod = importlib.import_module(f".{component_id}", __package__)
    return getattr(mod, _ADAPTER_CLASS[component_id])
