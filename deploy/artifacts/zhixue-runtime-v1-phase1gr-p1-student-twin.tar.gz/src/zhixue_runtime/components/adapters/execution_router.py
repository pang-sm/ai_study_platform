"""ExecutionRouter native adapter — DATA_PRODUCER / SHADOW CANDIDATE (route decision only).

Faithfully wraps the scientific route-decision logic from
``runtime_src/v1/execution_router/scripts/eval_routing.py``.

The route-decision callables ``eval_router`` / ``eval_cost_aware`` / ``build_cand`` are
AST-extracted at load time and *called* (single source of truth).  The q0/q1/cost VALUES are
data (fixture quality snapshot + bundled registry), not re-derived in the package — the
scientific formulas (``q0=mean success``, ``q1=Laplace(alpha=1)``, ``cost=registry benchmark``)
are NOT statically copied.  The "selected target + ranking" is a generic pandas argmax/argmin
over the ``cand`` frame the extracted ``build_cand`` produced.

This adapter NEVER executes a provider (no network, no API key).  ``controls_product_decision = False``.
"""
import os, json
import numpy as np
import pandas as pd

from .base import NativeComponentAdapter, NativeInferenceResult
from ...errors import InputValidationError
from ...scientific import ScientificSourceExtractor

_ROUTER_SOURCE = "execution_router/scripts/eval_routing.py"
_FUNCS = ["eval_router", "eval_cost_aware", "build_cand"]

_QUALITY_MODES = ("task_best", "quality_q1")

# minimal schema-valid scientific fixture (benchmark query_model_table.parquet is NOT bundled).
# Real PRIMARY-pool model ids + real registry benchmark cost; q0/q1 are schema-valid quality
# snapshots (quality is computed from benchmark data in the source, which is not bundled here).
_FIXTURE_MODELS = ["Qwen3-8B", "deepseek-v3-0324", "gemini-2.5-flash"]
_FIXTURE_Q0 = {"Qwen3-8B": 0.60, "deepseek-v3-0324": 0.75, "gemini-2.5-flash": 0.80}
_FIXTURE_Q1 = {
    "math500": {"Qwen3-8B": 0.70, "deepseek-v3-0324": 0.90, "gemini-2.5-flash": 0.85},
    "gpqa": {"Qwen3-8B": 0.40, "deepseek-v3-0324": 0.65, "gemini-2.5-flash": 0.75},
}


class ExecutionRouterAdapter(NativeComponentAdapter):
    component_id = "execution_router"
    product_role = "DATA_PRODUCER"
    controls_product_decision = False
    replacement_readiness = "COLLECTING_DATA"
    DATA_PRODUCER_CONTRACT = [
        "event_id", "request_context_reference", "task",
        "scientific_route", "actual_route", "latency", "cost",
        "quality", "success_outcome",
    ]

    def __init__(self, config):
        super().__init__(config)
        self._funcs = None
        self._ns = None
        self._prov = None
        self._cost = {}

    def _registry_path(self):
        return os.path.join(self.config.runtime_source_root, "execution_router", "registry", "model_registry.json")

    def load(self):
        if self.loaded:
            return self
        ext = ScientificSourceExtractor(self.config.runtime_source_root)
        funcs, ns, prov = ext.extract_functions(_ROUTER_SOURCE, _FUNCS)
        ns["np"] = np
        ns["pd"] = pd
        self._funcs, self._ns, self._prov = funcs, ns, prov

        # cost VALUES from the bundled registry (scientific COST source: eval_routing.py:11)
        reg = json.load(open(self._registry_path(), encoding="utf-8"))["models"]
        self._cost = {m: (reg[m]["benchmark_input_cost_per_row_mean"] or 0.0) for m in _FIXTURE_MODELS}
        self.loaded = True
        return self

    def unload(self):
        self._funcs = None
        self._ns = None
        self._prov = None
        self._cost = {}
        self.loaded = False

    def _frame(self, task):
        """Build the raw ``sdf`` and the ``cand`` (q0/q1/cost) frame via the extracted build_cand."""
        sdf = pd.DataFrame([{"query_id": 0, "task": task, "model_id": m,
                             "success": 0, "benchmark_cost": self._cost[m]}
                            for m in _FIXTURE_MODELS])
        # module globals the extracted build_cand / eval_router read (scientific state)
        self._ns["q0"] = pd.Series(_FIXTURE_Q0)
        self._ns["q1_map"] = {(t, m): v for t, d in _FIXTURE_Q1.items() for m, v in d.items()}
        self._ns["COST"] = self._cost
        cand = self._funcs["build_cand"](sdf)
        return sdf, cand

    def infer(self, task, mode, lam=None):
        if not self.loaded:
            self.load()
        if task not in _FIXTURE_Q1:
            raise InputValidationError(f"unknown task {task!r}")
        if mode not in ("task_best", "quality_q1", "cheapest", "best_single", "cost_aware"):
            raise InputValidationError(f"unknown route mode {mode!r}")
        if mode == "cost_aware" and (lam is None or not np.isfinite(float(lam))):
            raise InputValidationError("cost_aware mode requires finite lam")

        sdf, cand = self._frame(task)

        # route decision via the AST-extracted scientific functions (single source of truth)
        if mode == "cost_aware":
            scientific = self._funcs["eval_cost_aware"](sdf, float(lam))
        else:
            scientific = self._funcs["eval_router"](cand, mode)

        # selected target + ranking: generic pandas argmax/argmin over the cand frame
        # (the same selection the extracted eval_router/eval_cost_aware make internally)
        if mode in _QUALITY_MODES:
            score_col, score_name = "q1", "q1"
            selected = cand.loc[cand["q1"].idxmax(), "model_id"]
            ranking = cand.sort_values("q1", ascending=False)["model_id"].tolist()
        elif mode == "cheapest":
            score_col, score_name = "cost", "cost"
            selected = cand.loc[cand["cost"].idxmin(), "model_id"]
            ranking = cand.sort_values("cost", ascending=True)["model_id"].tolist()
        elif mode == "best_single":
            score_col, score_name = "q0", "q0"
            selected = cand.loc[cand["q0"].idxmax(), "model_id"]
            ranking = cand.sort_values("q0", ascending=False)["model_id"].tolist()
        else:  # cost_aware: utility = q1 - lam*cost (eval_routing.py:59, also computed by eval_cost_aware)
            score_col, score_name = "util", f"utility(q1 - {lam}*cost)"
            cand = cand.assign(util=cand["q1"] - float(lam) * cand["cost"])
            selected = cand.loc[cand["util"].idxmax(), "model_id"]
            ranking = cand.sort_values("util", ascending=False)["model_id"].tolist()

        target_scores = {m: round(float(cand.loc[cand["model_id"] == m, score_col].iloc[0]), 6)
                         for m in ranking}
        output = {
            "task": task,
            "mode": mode,
            "eligible_targets": list(_FIXTURE_MODELS),
            "ranking": ranking,
            "selected_target": selected,
            "routing_score_field": score_name,
            "routing_score": target_scores[selected],
            "target_scores": target_scores,
            "scientific_evaluation": scientific,   # extracted eval_router/eval_cost_aware output
            "costs": {m: self._cost[m] for m in ranking},
            "credential_configured": False,
            "provider_executed": False,
            "product_role": self.product_role,
            "controls_product_decision": self.controls_product_decision,
            "replacement_readiness": self.replacement_readiness,
        }
        return NativeInferenceResult(
            component_id=self.component_id, status="PASS", output=output,
            source_provenance={
                "source": _ROUTER_SOURCE,
                "source_sha256": self._prov["source_sha256"],
                "functions": list(_FUNCS),
                "linenos": self._prov["linenos"],
                "called": "eval_router / eval_cost_aware (route decision)",
                "q0_source": "eval_routing.py:19 train.groupby('model_id')['success'].mean()",
                "q1_source": "eval_routing.py:21-22 Laplace alpha=1: (sum+alpha)/(count+2*alpha)",
                "cost_source": "eval_routing.py:11 registry benchmark_input_cost_per_row_mean",
            },
            asset_provenance={"registry": "runtime_src/v1/execution_router/registry/model_registry.json",
                              "fixture": "minimal schema-valid (3 PRIMARY models, 2 tasks; q0/q1 synthetic quality snapshot)"},
        )

    def input_requirements(self):
        return [
            {"field": "task", "required": True, "semantic": "task family (e.g. math500, gpqa)"},
            {"field": "mode", "required": True, "semantic": "route mode: quality_q1/task_best/cheapest/best_single/cost_aware"},
            {"field": "lam", "required": False, "semantic": "cost weight (cost_aware only)"},
        ]

    def training_requirements(self):
        return {
            "trainable_model": False,
            "training_inputs": [],
            "labels": [],
            "evaluation_data_fields": ["scientific_route", "actual_route", "latency", "cost", "quality", "success_outcome"],
            "product_role": self.product_role,
            "controls_product_decision": self.controls_product_decision,
            "replacement_readiness": self.replacement_readiness,
            "data_producer_contract": self.DATA_PRODUCER_CONTRACT,
        }

    def health(self):
        h = super().health()
        h.update({"product_role": self.product_role, "controls_product_decision": self.controls_product_decision})
        return h
