"""LearnerState native adapter — DATA_PRODUCER, scientific VARIANT PANEL (knowledge tracing).

Wraps the knowledge-tracing models from ``runtime_src/v1/learner_state``:

    interaction sequence (skill q_t, prev response r_{t-1}) -> P(correct | history)

Five architecture families (source-backed, AST-extracted, NOT copied):
    DKT (LSTM), SimpleKT (causal transformer), AKT (monotonic attention),
    CGKT / CourseGraphKT (graph-GCN + transformer), CGKT-v2 (relational-attention transformer).

Output ``pred`` is ``next_response_probability`` (P(correct)), NOT a "mastery probability".

Scientific ontology is DIFFERENT from the product ontology:
  * base = ASSISTments (123 skills), junyi = Junyi (835 concepts)
  * product = Chinese CS/11408/programming
No Junyi->product mapping is built.  The adapter exposes a PANEL of representative
(engineering-only) variants; it never averages, votes, or auto-selects a winner.
``active_product_variant = NONE``.
"""
import os, gc
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import math

from .base import NativeComponentAdapter, NativeInferenceResult
from ...errors import InputValidationError, InferenceError, AssetMissingError
from ...scientific import ScientificSourceExtractor

_SRC = "learner_state/src/models/"
SOURCE_CLASS = "ORIGINAL_ARCHIVE_VERIFIED"

# representative Tier-A variants (one per family; lowest seed 42 + real graph).
# engineering_representative_only = True — NOT a production selection.
REPRESENTATIVES = [
    {"family": "DKT",     "class": "DKT",            "source": _SRC + "dkt.py",
     "checkpoint": "seed42/dkt/best.pt", "ontology": "base", "graph": None, "num_param": "num_skills"},
    {"family": "SimpleKT", "class": "SimpleKT",       "source": _SRC + "simplekt.py",
     "checkpoint": "seed42/simplekt/best.pt", "ontology": "base", "graph": None, "num_param": "num_skills"},
    {"family": "AKT",     "class": "AKT",            "source": _SRC + "akt.py",
     "checkpoint": "seed42/akt/best.pt", "ontology": "base", "graph": None, "num_param": "num_skills"},
    {"family": "CGKT",    "class": "CourseGraphKT",  "source": _SRC + "coursegraph_kt.py",
     "checkpoint": "seed42/cgkt_realgraph/best.pt", "ontology": "base", "graph": "real", "num_param": "num_skills"},
    {"family": "CGKT_v2", "class": "CourseGraphKTV2", "source": _SRC + "coursegraph_kt_v2.py",
     "checkpoint": "junyi/seed42/cgkt_v2_realgraph/best.pt", "ontology": "junyi", "graph": "real", "num_param": "num_concepts"},
]

# extraction specs: (rel_path, [symbols]) — model classes + shared helpers (common/gcn)
_EXTRACT = [
    (_SRC + "common.py", ["CosinePositionalEmbedding", "MultiHeadAttention", "TransformerBlock",
                          "_output_head", "_attn_mask"]),
    (_SRC + "gcn.py", ["GCN"]),
    (_SRC + "dkt.py", ["DKT"]),
    (_SRC + "simplekt.py", ["SimpleKT"]),
    (_SRC + "akt.py", ["AKT"]),
    (_SRC + "coursegraph_kt.py", ["CourseGraphKT"]),
    (_SRC + "coursegraph_kt_v2.py", ["CourseGraphKTV2", "RelationalAttention", "RelationalBlock"]),
]


class LearnerStateAdapter(NativeComponentAdapter):
    component_id = "learner_state"
    source_class = SOURCE_CLASS
    product_role = "DATA_PRODUCER"
    controls_product_decision = False
    variant_mode = "PANEL"
    active_product_variant = None
    replacement_readiness = "COLLECTING_DATA"

    DATA_PRODUCER_CONTRACT = [
        "event_id", "user_ref", "concept_id", "question_id",
        "sequence_position", "correctness", "response_time", "attempt_no",
        "scientific_family", "scientific_variant", "next_response_score", "latent_state_summary",
        "actual_next_correctness", "retry_outcome", "review_outcome", "later_mastery_proxy",
    ]

    def __init__(self, config):
        super().__init__(config)
        self._classes = {}    # family -> model class
        self._models = {}     # family -> instantiated model (eval)
        self._num_skills = {} # family -> ontology size
        self._prov = {}

    def _asset_dir(self):
        return os.path.join(self.config.model_asset_root, "learner_state")

    def load(self):
        if self.loaded:
            return self
        ext = ScientificSourceExtractor(self.config.runtime_source_root)
        ns = {"torch": torch, "nn": nn, "F": F, "math": math, "np": np}
        ns, prov = ext.extract_symbols(_EXTRACT, namespace=ns)
        self._prov = prov

        asset = self._asset_dir()
        for rep in REPRESENTATIVES:
            cls = ns[rep["class"]]
            self._classes[rep["family"]] = cls
            p = os.path.join(asset, rep["checkpoint"].replace("/", os.sep))
            if not os.path.exists(p):
                raise AssetMissingError(f"learner_state checkpoint missing: {p}")
            sd = torch.load(p, map_location="cpu")
            num_skills = self._num_skills_from(sd)
            kw = {rep["num_param"]: num_skills}
            if rep["graph"] is not None:
                kw["graph_mode"] = rep["graph"]
            model = cls(**kw)
            model.load_state_dict(sd)
            model.eval()
            self._models[rep["family"]] = model
            self._num_skills[rep["family"]] = num_skills

        self.loaded = True
        return self

    @staticmethod
    def _num_skills_from(sd):
        if "out.weight" in sd:
            return int(sd["out.weight"].shape[0])          # DKT
        if "q_embed.weight" in sd:
            return int(sd["q_embed.weight"].shape[0]) - 1  # SimpleKT/AKT
        if "concept_emb.weight" in sd:
            return int(sd["concept_emb.weight"].shape[0]) - 1  # CGKT/CGKT-v2
        raise InferenceError("cannot determine num_skills from checkpoint")

    def unload(self):
        self._classes = {}
        self._models = {}
        self._num_skills = {}
        self.loaded = False
        gc.collect()

    # ---------------------------------------------------------------- inference
    def _validate(self, q, r_prev, mask, num_skills):
        q = np.asarray(q, dtype=np.int64).reshape(1, -1)
        r = np.asarray(r_prev, dtype=np.int64).reshape(1, -1)
        if q.shape != r.shape:
            raise InputValidationError("q and r_prev must have the same length")
        if not ((r == 0) | (r == 1)).all():
            raise InputValidationError("r_prev must be 0/1")
        if (q < 0).any() or (q >= num_skills).any():
            raise InputValidationError(f"q skill idx out of range [0,{num_skills})")
        if mask is not None:
            mask = np.asarray(mask, dtype=np.float32).reshape(1, -1)
            if mask.shape != q.shape:
                raise InputValidationError("mask shape mismatch")
        return q, r, mask

    def infer(self, family, q, r_prev, mask=None):
        """Next-response prediction for ONE family.  Output is P(correct)."""
        if not self.loaded:
            self.load()
        if family not in self._models:
            raise InputValidationError(f"unknown family {family!r}; valid={sorted(self._models)}")
        num_skills = self._num_skills[family]
        q, r, mask = self._validate(q, r_prev, mask, num_skills)
        q_t = torch.tensor(q); r_t = torch.tensor(r)
        m_t = torch.tensor(mask) if mask is not None else None
        with torch.no_grad():
            pred = self._models[family](q_t, r_t, m_t)
        pred = pred[0].cpu().numpy()
        if not np.isfinite(pred).all():
            raise InferenceError(f"family {family} prediction not finite")
        if not (0.0 <= pred).all() and (pred <= 1.0).all():
            raise InferenceError(f"family {family} prediction out of [0,1]")

        rep = next(x for x in REPRESENTATIVES if x["family"] == family)
        output = {
            "family": family,
            "variant_id": rep["checkpoint"],
            "ontology": rep["ontology"],
            "num_skills": num_skills,
            "next_response_probability": [round(float(p), 6) for p in pred],
            "score_semantics": "next_response_probability P(correct) — NOT mastery probability",
            "engineering_representative_only": True,
            "product_role": self.product_role,
            "controls_product_decision": self.controls_product_decision,
            "variant_mode": self.variant_mode,
            "active_product_variant": self.active_product_variant,
            "replacement_readiness": self.replacement_readiness,
        }
        return NativeInferenceResult(component_id=self.component_id, status="PASS", output=output,
                                     source_provenance=self._prov,
                                     asset_provenance={"checkpoint": f"model_assets/v1/learner_state/{rep['checkpoint']}"})

    def infer_panel(self, q, r_prev, mask=None, families=None):
        """Panel over compatible families (same ontology).  No averaging/voting."""
        if not self.loaded:
            self.load()
        families = families or sorted(self._models)
        # separate by ontology: base (123) vs junyi (835) can't share a q sequence
        preds = {}
        for fam in families:
            r = self.infer(fam, q, r_prev, mask)
            preds[fam] = r.output["next_response_probability"]
        output = {
            "variant_outputs": preds,
            "averaging": False,
            "auto_selection": False,
            "active_product_variant": self.active_product_variant,
            "product_role": self.product_role,
            "controls_product_decision": self.controls_product_decision,
            "variant_mode": self.variant_mode,
            "replacement_readiness": self.replacement_readiness,
        }
        return NativeInferenceResult(component_id=self.component_id, status="PASS", output=output,
                                     source_provenance=self._prov,
                                     asset_provenance={"checkpoints": "model_assets/v1/learner_state/{seed42}/..."})

    # ---------------------------------------------------------------- metadata
    def input_requirements(self):
        return [
            {"field": "q", "required": True, "semantic": "skill/concept index sequence (pad = num_skills)"},
            {"field": "r_prev", "required": True, "semantic": "previous-response sequence (0/1)"},
            {"field": "mask", "required": False, "semantic": "sequence mask"},
            {"field": "family", "required": True, "semantic": "one of DKT/SimpleKT/AKT/CGKT/CGKT_v2"},
        ]

    def training_requirements(self):
        return {
            "trainable_model": True,
            "inputs": "interaction sequence (q_t skill idx + r_{t-1} prev response)",
            "labels": "next-response correctness (binary, self-supervised from history)",
            "negative_sampling": "none (next-response prediction)",
            "ontology": "base ASSISTments (123 skills) + junyi (835 concepts) — DIFFERENT from product",
            "encoder": "per-family (LSTM / transformer / GCN+transformer / relational-attention)",
            "unresolved": ["product ontology mapping (DIFFERENT; not resolved this phase)"],
        }

    def health(self):
        h = super().health()
        h.update({"product_role": self.product_role, "controls_product_decision": self.controls_product_decision,
                  "variant_mode": self.variant_mode, "active_product_variant": self.active_product_variant})
        return h
