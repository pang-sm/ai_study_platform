import os, math, numpy as np
from .base import NativeComponentAdapter, NativeInferenceResult
from ...errors import InputValidationError, InferenceError

class DifficultyPriorAdapter(NativeComponentAdapter):
    component_id = "difficulty_prior"
    def __init__(self, config):
        super().__init__(config)
        self._coef = None; self._intercept = None; self._dim = None
    def _asset(self, seed=42):
        return os.path.join(self.config.model_asset_root, "difficulty_prior", f"seed{seed}")
    def load(self):
        d = self._asset()
        coef = np.load(os.path.join(d, "ridge_coef.npy"))
        intercept = np.load(os.path.join(d, "ridge_intercept.npy")).reshape(-1)
        self._coef = coef; self._intercept = intercept; self._dim = coef.shape[0] if coef.ndim == 1 else coef.shape[1]
        self.loaded = True
        return self
    def _validate(self, features):
        x = np.asarray(features, dtype=np.float64).reshape(1, -1)
        if x.shape[1] != self._dim:
            raise InputValidationError(f"feature dim {x.shape[1]} != expected {self._dim}")
        if not np.isfinite(x).all():
            raise InputValidationError("features contain NaN/Inf")
        return x
    def infer(self, features):
        if not self.loaded: self.load()
        x = self._validate(features)
        # use sklearn Ridge.predict (real scientific implementation): y = X @ coef_.T + intercept_
        try:
            from sklearn.linear_model import Ridge
            r = Ridge(); r.coef_ = self._coef.reshape(1, -1); r.intercept_ = self._intercept.reshape(-1)
            y = float(np.asarray(r.predict(x)).ravel()[0])
        except Exception as e:
            raise InferenceError(f"ridge predict failed: {e}")
        if not math.isfinite(y):
            raise InferenceError("difficulty output not finite")
        return NativeInferenceResult(component_id=self.component_id, status="PASS", output={"difficulty": y},
            source_provenance={"entrypoint": "sklearn Ridge.predict", "source": "difficulty_prior/src/difficulty/run_difficulty.py"},
            asset_provenance={"ridge_coef.npy": str(self._dim) + "-dim"})
    def input_requirements(self):
        return [{"field": "features", "dim": self._dim or "unknown", "semantic": "BGE-M3 text embedding (pre-computed)", "required": True}]
