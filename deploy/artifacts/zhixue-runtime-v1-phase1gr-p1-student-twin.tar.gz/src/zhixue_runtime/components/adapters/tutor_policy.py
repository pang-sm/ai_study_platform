"""TutorPolicy native adapter — DATA_PRODUCER / SHADOW CANDIDATE.

Wraps the scientific EncoderPolicy (BGE-M3 + 4-way action classification head) from
``runtime_src/v1/tutor_policy``:

    FULL_STATE -> P(action) over {focus, generic, probing, telling}

The input-state construction ``build_texts(dp, "FULL_STATE")`` is loaded via
ScientificSourceLoader (single source of truth).  The 4-way action ontology is EXACTLY
identical to TutorGuard's (focus=0, generic=1, probing=2, telling=3).  The mean-pool + head
forward is a faithful equivalent of ``EncoderPolicy.forward`` (train_encoder_policy.py:51-54).

Historical: L3 macro-F1 0.48 +/- 0.04 (SUPPORTED — beats majority 0.12, prev-action 0.36,
TF-IDF 0.42).  product_role=DATA_PRODUCER; controls_product_decision=false.
"""
import os, json, gc
import torch
import torch.nn as nn
from transformers import AutoModel, AutoTokenizer

from .base import NativeComponentAdapter, NativeInferenceResult, ScientificSourceLoader
from ...errors import InputValidationError, InferenceError, AssetMissingError

_FEATURES_SOURCE = "tutor_policy/src/data/features.py"
_POLICY_SOURCE = "tutor_policy/src/policy/train_encoder_policy.py"

SOURCE_CLASS = "ORIGINAL_ARCHIVE_VERIFIED"

# 4-way pedagogical action ontology (EXACT match with TutorGuard)
ACTION_ONTOLOGY = ["focus", "generic", "probing", "telling"]
ACTION_INDEX = {0: "focus", 1: "generic", 2: "probing", 3: "telling"}


class TutorPolicyAdapter(NativeComponentAdapter):
    component_id = "tutor_policy"
    source_class = SOURCE_CLASS
    product_role = "DATA_PRODUCER"
    controls_product_decision = False
    replacement_readiness = "COLLECTING_DATA"
    replacement_priority = "HIGH"   # macro-F1 ~0.48 (weak-but-supported); priority for V2 replacement
    ACTION_ONTOLOGY = ACTION_ONTOLOGY
    ACTION_INDEX = ACTION_INDEX

    DATA_PRODUCER_CONTRACT = [
        "event_id", "learner_state_reference", "policy_requested_action",
        "policy_action_probabilities", "generated_tutor_response",
        "guard_observed_action", "guard_compliance_score", "guard_reveal_score",
        "policy_guard_agreement", "learner_response", "immediate_correctness", "later_mastery",
    ]

    def __init__(self, config, seed=42):
        super().__init__(config)
        self.seed = seed
        self._encoder = None       # heavy (BGE-M3 XLMRobertaModel)
        self._head = None          # nn.Linear(1024, 4)
        self._tokenizer = None
        self._build_texts = None   # scientific callable (features.py::build_texts)
        self._actions = list(ACTION_ONTOLOGY)
        self._prov = {}

    def _asset_dir(self):
        return os.path.join(self.config.model_asset_root, "tutor_policy")

    def load(self):
        if self.loaded:
            return self
        asset = self._asset_dir()
        enc_dir = os.path.join(asset, "encoder_policy", f"seed{self.seed}", "encoder")
        head_pt = os.path.join(asset, "encoder_policy", f"seed{self.seed}", "head.pt")
        for f in ("config.json", "model.safetensors", "tokenizer.json", "tokenizer_config.json"):
            if not os.path.exists(os.path.join(enc_dir, f)):
                raise AssetMissingError(f"tutor_policy checkpoint missing: {enc_dir}/{f}")
        if not os.path.exists(head_pt):
            raise AssetMissingError(f"tutor_policy head missing: {head_pt}")

        # scientific callables (single source of truth)
        loader = ScientificSourceLoader(self.config.runtime_source_root)
        features = loader.load_module(_FEATURES_SOURCE, "_tp_features_sci")
        self._build_texts = features.build_texts
        # authoritative action ontology (pedagogical_action_ontology.json)
        ontology_path = os.path.join(self.config.runtime_source_root, "tutor_policy",
                                     "data", "ontology", "pedagogical_action_ontology.json")
        ontology = json.load(open(ontology_path, encoding="utf-8"))
        self._actions = [a["name"] for a in ontology["actions"]]

        # self-contained BGE-M3 encoder + 4-way head; CPU float32 (engineering adaptation)
        self._tokenizer = AutoTokenizer.from_pretrained(enc_dir, local_files_only=True)
        self._encoder = AutoModel.from_pretrained(enc_dir, dtype=torch.float32, local_files_only=True).eval()
        self._head = nn.Linear(self._encoder.config.hidden_size, 4)
        self._head.load_state_dict(torch.load(head_pt, map_location="cpu"))
        self._head.eval()

        self._prov = {
            "source_class": self.source_class, "source_repo": "tutor_policy", "source_commit": "b716ae77e",
            "features_source": _FEATURES_SOURCE, "policy_source": _POLICY_SOURCE,
            "input_construction": "features.py::build_texts(mode=FULL_STATE)",
            "forward": "train_encoder_policy.py:51-54 EncoderPolicy.forward (mean-pool + 4-way head)",
            "action_ontology": self._actions,
            "action_index": ACTION_INDEX,
        }
        self.loaded = True
        return self

    def unload(self):
        self._encoder = None
        self._head = None
        self._tokenizer = None
        self._build_texts = None
        self.loaded = False
        gc.collect()

    # ---------------------------------------------------------------- inference
    def _validate(self, problem, wrong, profile, confusion, prev_actions, history):
        if not isinstance(problem, str) or not problem.strip():
            raise InputValidationError("problem must be a non-empty string")
        if not isinstance(wrong, str) or not wrong.strip():
            raise InputValidationError("wrong (student incorrect solution) must be a non-empty string")
        if profile is None:
            profile = ""
        if confusion is None:
            confusion = ""
        if not isinstance(profile, str) or not isinstance(confusion, str):
            raise InputValidationError("profile/confusion must be strings")
        if prev_actions is None:
            prev_actions = []
        if history is None:
            history = []
        if not isinstance(prev_actions, list) or not isinstance(history, list):
            raise InputValidationError("prev_actions/history must be lists")
        for a in prev_actions:
            if a not in self._actions:
                raise InputValidationError(f"prev_action {a!r} not in ontology {self._actions}")
        for h in history:
            if not isinstance(h, (list, tuple)) or len(h) != 2:
                raise InputValidationError("history entries must be [speaker, text] pairs")
        return profile, confusion, prev_actions, history

    def infer(self, problem, wrong, profile=None, confusion=None, prev_actions=None, history=None):
        if not self.loaded:
            self.load()
        profile, confusion, prev_actions, history = self._validate(
            problem, wrong, profile, confusion, prev_actions, history)
        dp = {"problem": problem, "wrong": wrong, "profile": profile, "confusion": confusion,
              "prev_actions": prev_actions, "history": history}
        text = self._build_texts(dp, "FULL_STATE")

        enc = self._tokenizer(text, truncation=True, max_length=512, return_tensors="pt")
        with torch.no_grad():
            out = self._encoder(**enc).last_hidden_state
            # EncoderPolicy.forward: mean-pool over attention mask + 4-way head
            pooled = (out * enc["attention_mask"].unsqueeze(-1).float()).sum(1) / \
                     enc["attention_mask"].sum(1).clamp(min=1).unsqueeze(-1)
            logits = self._head(pooled)
        logits = logits[0].detach().cpu().numpy()
        probs = torch.softmax(torch.tensor(logits), dim=-1).numpy()
        if not all(-1e9 < x < 1e9 for x in logits):
            raise InferenceError("tutor_policy logits not finite")

        action_probs = {self._actions[i]: round(float(probs[i]), 6) for i in range(4)}
        ranking = sorted(self._actions, key=lambda a: -action_probs[a])
        selected = ranking[0]
        output = {
            "requested_action": selected,
            "action_probabilities": action_probs,
            "ranking": ranking,
            "action_ontology": list(self._actions),
            "action_index": dict(ACTION_INDEX),
            "logits": [round(float(x), 6) for x in logits],
            "product_role": self.product_role,
            "controls_product_decision": self.controls_product_decision,
            "replacement_readiness": self.replacement_readiness,
            "replacement_priority": self.replacement_priority,
            "source_class": self.source_class,
        }
        return NativeInferenceResult(
            component_id=self.component_id, status="PASS", output=output,
            source_provenance=self._prov,
            asset_provenance={"checkpoint": f"model_assets/v1/tutor_policy/encoder_policy/seed{self.seed}",
                              "tokenizer": f"model_assets/v1/tutor_policy/encoder_policy/seed{self.seed}/encoder"},
        )

    # ---------------------------------------------------------------- metadata
    def input_requirements(self):
        return [
            {"field": "problem", "required": True, "semantic": "problem text"},
            {"field": "wrong", "required": True, "semantic": "student incorrect solution"},
            {"field": "profile", "required": False, "semantic": "student profile"},
            {"field": "confusion", "required": False, "semantic": "teacher-described confusion"},
            {"field": "prev_actions", "required": False, "semantic": "list of prior pedagogical actions"},
            {"field": "history", "required": False, "semantic": "dialogue history [[speaker, text], ...]"},
        ]

    def training_requirements(self):
        return {
            "trainable_model": True,
            "inputs": "FULL_STATE (problem + error + profile + confusion + prev_actions + dialogue)",
            "labels": "pedagogical action (4-way: focus/generic/probing/telling)",
            "action_ontology": self._actions,
            "loss": "CrossEntropyLoss (raw, no class weight)",
            "class_balancing": "none (class imbalance: focus 5549 > generic 3566 > probing 3300 > telling 2493)",
            "base_model": "BGE-M3 (XLMRobertaModel, hidden 1024)",
            "context_requirement": "dialogue history + previous actions (dominant signal)",
            "unresolved": ["action->outcome causal utility (confounded; CLAIM_5 NOT_SUPPORTED)"],
        }

    def health(self):
        h = super().health()
        h.update({"product_role": self.product_role, "controls_product_decision": self.controls_product_decision,
                  "source_class": self.source_class})
        return h
