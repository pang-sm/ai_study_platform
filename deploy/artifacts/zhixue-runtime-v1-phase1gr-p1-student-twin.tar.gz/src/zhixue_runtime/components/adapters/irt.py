import os, math, importlib.util, hashlib
import pandas as pd
from .base import NativeComponentAdapter, NativeInferenceResult
from ...errors import InputValidationError, InferenceError

_IRT_SOURCE = "irt/src/evaluation/irt_cat.py"

def _load_sigmoid_and_source():
    p = os.path.join(os.environ.get("ZHIXUE_HOME", ""), "runtime_src", "v1", "irt", "src", "evaluation", "irt_cat.py")
    with open(p, "rb") as f:
        content = f.read()
    sha = hashlib.sha256(content).hexdigest()
    spec = importlib.util.spec_from_file_location("_irt_cat_sci", p)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod.sigmoid, {"source_path": _IRT_SOURCE, "source_sha256": sha, "line": 69}

class IRTAdapter(NativeComponentAdapter):
    component_id = "irt"
    def __init__(self, config):
        super().__init__(config)
        self._b = None
    def load(self):
        p = os.path.join(self.config.model_asset_root, "irt", "item_parameters.parquet")
        items = pd.read_parquet(p)
        self._b = dict(zip(items["item_id"].astype(str), items["difficulty_b"]))
        self._sigmoid, self._prov = _load_sigmoid_and_source()
        self.loaded = True
        return self
    def _validate(self, item_id, theta):
        if item_id not in self._b:
            raise InputValidationError(f"item {item_id} not in item_parameters (no fallback)")
        if not math.isfinite(float(theta)): raise InputValidationError("theta not finite")
    def infer(self, item_id, theta, correct):
        if not self.loaded: self.load()
        self._validate(item_id, theta)
        b = self._b[item_id]
        p = self._sigmoid(theta - b)          # 1PL: P(correct) = sigmoid(theta - b), uses imported sigmoid (single source)
        new_theta = theta + (correct - p)     # online 1PL-style theta update (irt_cat.py line 69: th += (c - p))
        return NativeInferenceResult(component_id=self.component_id, status="PASS",
            output={"p_correct": float(p), "theta": float(theta), "theta_updated": float(new_theta), "b_item": float(b)},
            source_provenance={"entrypoint": "sigmoid (imported) + online 1PL-style theta update", **self._prov},
            asset_provenance={"item_parameters.parquet": "1PL b_i"})
    def input_requirements(self):
        return [{"field": "item_id", "required": True}, {"field": "theta", "required": True}, {"field": "correct", "required": True}]
