import json, os
from .base import NativeComponentAdapter, NativeInferenceResult

class DomesticRegistryAdapter(NativeComponentAdapter):
    component_id = "domestic_registry"
    def __init__(self, config):
        super().__init__(config)
        self._registry = None
    def _asset_path(self):
        return os.path.join(self.config.model_asset_root, "domestic_registry", "model_registry.json")
    def load(self):
        p = self._asset_path()
        with open(p, encoding="utf-8") as f:
            self._registry = json.load(f)
        self.loaded = True
        return self
    def infer(self, provider=None, capability=None):
        if not self.loaded:
            self.load()
        models = self._registry.get("models", [])
        out = []
        for prof in models:
            if provider and prof.get("provider") != provider:
                continue
            if capability and not prof.get(capability):
                continue
            out.append({
                "model_id": prof.get("model_id"),
                "provider": prof.get("provider"),
                "deployment_type": prof.get("deployment_type"),
                "production_cost": prof.get("production_cost"),
                "access_status": prof.get("health_status"),
                "quality_status": prof.get("quality_status"),
            })
        return NativeInferenceResult(component_id=self.component_id, status="PASS", output={"count": len(out), "models": out},
                                     source_provenance={"type": "registry_json"}, asset_provenance={"path": "model_assets/v1/domestic_registry/model_registry.json"})
    def input_requirements(self):
        return [{"field": "provider", "required": False}, {"field": "capability", "required": False}]
