import os, time, hashlib, importlib.util
from typing import Any, Dict, Optional
from dataclasses import dataclass, field

class ScientificSourceLoader:
    """Safe legacy scientific module loader (importlib, path-resolved, no global sys.path mutation)."""
    def __init__(self, source_root: str):
        self.source_root = os.path.abspath(source_root)
    def load_module(self, rel_path: str, module_name: str):
        p = os.path.join(self.source_root, rel_path.replace("/", os.sep))
        if not os.path.exists(p):
            raise FileNotFoundError(f"scientific source missing: {rel_path}")
        spec = importlib.util.spec_from_file_location(module_name, p)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod

@dataclass
class NativeInferenceResult:
    component_id: str
    status: str
    output: Any = None
    output_schema_version: str = "v1"
    scientific_variant: str = None
    runtime_version: str = "0.1.0"
    source_provenance: dict = field(default_factory=dict)
    asset_provenance: dict = field(default_factory=dict)
    started_at: float = 0.0
    duration_ms: float = 0.0
    warnings: list = field(default_factory=list)

class NativeComponentAdapter:
    component_id = None
    def __init__(self, config):
        self.config = config
        self.loaded = False
    def load(self): raise NotImplementedError
    def infer(self, *a, **k): raise NotImplementedError
    def unload(self): self.loaded = False
    def health(self): return {"component_id": self.component_id, "loaded": self.loaded}
    def provenance(self): return {"component_id": self.component_id, "runtime_version": "0.1.0"}
    def input_requirements(self): return []
    def training_requirements(self): return []
