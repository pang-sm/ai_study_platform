import os, json, math, torch, torch.nn as nn
from .base import NativeComponentAdapter, NativeInferenceResult
from ...errors import InputValidationError, InferenceError
from ...scientific import ScientificSourceExtractor

FEATURE_ORDER = ["log_dt", "hist_len", "mean_interval", "mean_rating", "last_rating", "lapses"]
_MEM_SOURCE = "memory/src/evaluation/v11_calibration.py"

class MemoryAdapter(NativeComponentAdapter):
    component_id = "memory"
    def __init__(self, config):
        super().__init__(config)
        self._net = None; self._platt = None; self._class_provenance = None
    def load(self):
        d = os.path.join(self.config.model_asset_root, "memory")
        sd = torch.load(os.path.join(d, "model_state_dict.pt"), map_location="cpu")
        ext = ScientificSourceExtractor(self.config.runtime_source_root)
        MemNet, prov = ext.extract_class(_MEM_SOURCE, "MemNet")
        net = MemNet(); net.load_state_dict(sd); net.eval()
        self._net = net; self._class_provenance = prov
        self._platt = json.load(open(os.path.join(d, "platt_calibration.json")))
        self.loaded = True
        return self
    def _validate(self, inp):
        for k in FEATURE_ORDER:
            if k not in inp: raise InputValidationError(f"missing field {k}")
        if inp.get("hist_len", 0) < 0: raise InputValidationError("hist_len < 0")
        if inp.get("lapses", 0) < 0: raise InputValidationError("lapses < 0")
        for k in FEATURE_ORDER:
            if not math.isfinite(float(inp[k])): raise InputValidationError(f"{k} not finite")
    def infer(self, **inp):
        if not self.loaded: self.load()
        self._validate(inp)
        x = torch.tensor([[inp[k] for k in FEATURE_ORDER]], dtype=torch.float32)
        dt = torch.tensor([[inp.get("delta_t", 1.0)]], dtype=torch.float32)
        with torch.no_grad():
            raw = float(self._net(x, dt))
        slope = self._platt["coefficient_slope"]; intercept = self._platt["intercept"]
        cal = 1/(1+math.exp(-(slope*raw + intercept)))
        if not (0 <= cal <= 1): raise InferenceError("calibrated prob out of [0,1]")
        return NativeInferenceResult(component_id=self.component_id, status="PASS",
            output={"raw_recall_prob": raw, "calibrated_recall_prob": cal},
            source_provenance={"entrypoint": "MemNet.forward (AST-extracted from runtime_src)", **self._class_provenance},
            asset_provenance={"model_state_dict.pt": "MemNet 6->32->2"})
    def input_requirements(self):
        return [{"field": k, "required": True} for k in FEATURE_ORDER] + [{"field": "delta_t", "required": True}]
