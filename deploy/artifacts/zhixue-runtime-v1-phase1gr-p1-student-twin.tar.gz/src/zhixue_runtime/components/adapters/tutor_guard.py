"""TutorGuard native adapter — DATA_PRODUCER / SHADOW CANDIDATE.

Faithfully wraps the scientific TutorGuard stack:

    frozen candidate pool  ->  reveal detector  ->  ActionRecognizer
        ->  compliance score  ->  best-of-N  ->  selected candidate

Single source of truth:
  * reveal detector + best-of-N constants: runtime_src/v1/tutor_guard
    (guard_eval.py ``reveal``/``NON_TELLING``; validate.py ``careful_reveal``)
  * ActionRecognizer + frozen pool: model_assets/v1/tutor_guard/scientific/

This adapter is a DATA_PRODUCER: it runs the real scientific stack to produce
observations/training data but does NOT control the product tutor response
(``controls_product_decision = False``).  The divergent reconstructed
``model_assets/v1/tutor_guard/guard.py`` is NOT used.
"""
import os, json, gc
import torch, torch.nn as nn
from transformers import AutoModel, AutoTokenizer

from .base import NativeComponentAdapter, NativeInferenceResult, ScientificSourceLoader
from ...errors import InputValidationError, InferenceError, AssetMissingError, SourceMissingError

_TG_GUARD_EVAL = "tutor_guard/src/evaluation/guard_eval.py"
_TG_VALIDATE = "tutor_guard/src/evaluation/validate.py"


class TutorGuardAdapter(NativeComponentAdapter):
    component_id = "tutor_guard"
    product_role = "DATA_PRODUCER"
    controls_product_decision = False
    replacement_readiness = "COLLECTING_DATA"
    # future product dataset schema (schema/metadata only — no DB written here)
    DATA_PRODUCER_CONTRACT = [
        "event_id", "session_context_ref", "requested_action",
        "candidate_id", "candidate_hash", "reveal_flag", "careful_reveal_flag",
        "compliance_scores", "scientific_selected_candidate",
        "actual_product_candidate", "actual_product_response",
        "guard_agreed_with_product", "eventual_learning_outcome",
    ]

    def __init__(self, config):
        super().__init__(config)
        self._recognizer = None   # (tokenizer, encoder, head) — heavy
        self._sci = None          # scientific callables + constants from runtime_src
        self._candidates = []     # frozen candidate pool

    # ------------------------------------------------------------------ paths
    def _scientific_dir(self):
        return os.path.join(self.config.model_asset_root, "tutor_guard", "scientific")

    def _recognizer_dir(self):
        return os.path.join(self._scientific_dir(), "action_recognizer")

    def _candidates_path(self):
        return os.path.join(self._scientific_dir(), "data", "candidates.jsonl")

    # ------------------------------------------- scientific source (single truth)
    def _load_scientific(self):
        loader = ScientificSourceLoader(self.config.runtime_source_root)
        guard = loader.load_module(_TG_GUARD_EVAL, "_tutor_guard_guard_eval_sci")
        valid = loader.load_module(_TG_VALIDATE, "_tutor_guard_validate_sci")
        return {
            "reveal": guard.reveal,
            "careful_reveal": valid.careful_reveal,
            "ACTIONS": list(guard.ACTIONS),
            "NON_TELLING": list(guard.NON_TELLING),
        }

    # ------------------------------------------- ActionRecognizer (heavy, CPU fp32)
    def _load_recognizer(self):
        rd = self._recognizer_dir()
        encoder_dir = os.path.join(rd, "encoder")
        head_pt = os.path.join(rd, "head.pt")
        for p in (os.path.join(encoder_dir, "config.json"),
                  os.path.join(encoder_dir, "model.safetensors"),
                  os.path.join(encoder_dir, "tokenizer.json"),
                  os.path.join(encoder_dir, "tokenizer_config.json"),
                  head_pt):
            if not os.path.exists(p):
                raise AssetMissingError(f"tutor_guard scientific asset missing: {p}")
        tok = AutoTokenizer.from_pretrained(encoder_dir, local_files_only=True)
        # device/dtype engineering adaptation: CPU + float32 (model structure/weights unchanged)
        enc = AutoModel.from_pretrained(encoder_dir, dtype=torch.float32, local_files_only=True)
        enc.eval()
        head = nn.Linear(enc.config.hidden_size, 4)
        head.load_state_dict(torch.load(head_pt, map_location="cpu"))  # strict
        head.eval()
        return tok, enc, head

    # ----------------------------------------------------------------- load / unload
    def load(self):
        if self.loaded:
            return self
        self._sci = self._load_scientific()
        self._recognizer = self._load_recognizer()
        cp = self._candidates_path()
        if not os.path.exists(cp):
            raise AssetMissingError(f"tutor_guard frozen candidate pool missing: {cp}")
        with open(cp, encoding="utf-8") as f:
            self._candidates = [json.loads(l) for l in f if l.strip()]
        self.loaded = True
        return self

    def unload(self):
        self._recognizer = None
        self._sci = None
        self._candidates = []
        self.loaded = False
        gc.collect()

    # ------------------------------------------------------- scientific compliance
    def _compliance_probs(self, response):
        tok, enc, head = self._recognizer
        e = tok(response, truncation=True, max_length=64, return_tensors="pt")
        with torch.no_grad():
            out = enc(**e).last_hidden_state
            pooled = (out * e["attention_mask"].unsqueeze(-1).float()).sum(1) / \
                     e["attention_mask"].sum(1).clamp(min=1).unsqueeze(-1)
            logits = head(pooled)
        return torch.softmax(logits, -1)[0].detach().cpu().numpy()

    def _score(self, c):
        probs = self._compliance_probs(c["response"])
        idx = self._sci["ACTIONS"].index(c["requested_action"])
        return {
            "reveal": int(self._sci["reveal"](c["response"], c["ground_truth"])),
            "careful_reveal": int(self._sci["careful_reveal"](c["response"], c["ground_truth"])),
            "compliance_score": float(probs[idx]),
        }

    # -------------------------------------------------- best-of-N (guard_eval.py pick mode="guard" equivalent)
    def _select(self, group):
        scored = [dict(c, **self._score(c)) for c in group]
        if group[0]["requested_action"] in self._sci["NON_TELLING"]:
            safe = [s for s in scored if not s["reveal"]]
            if safe:
                return max(safe, key=lambda s: s["compliance_score"]), scored
            return max(scored, key=lambda s: s["compliance_score"]), scored
        return max(scored, key=lambda s: s["compliance_score"]), scored

    # ---------------------------------------------------------------------- infer
    def infer(self, state_id, requested_action):
        if not self.loaded:
            self.load()
        if requested_action not in self._sci["ACTIONS"]:
            raise InputValidationError(f"requested_action {requested_action!r} not in {self._sci['ACTIONS']}")
        try:
            sid = int(state_id)
        except (TypeError, ValueError):
            raise InputValidationError(f"state_id must be int-like, got {state_id!r}")

        group = [c for c in self._candidates if c["state_id"] == sid and c["requested_action"] == requested_action]
        if not group:
            raise InputValidationError(f"no candidates for state_id={sid} action={requested_action!r}")

        selected, scored = self._select(group)
        non_revealing = [s for s in scored if not s["reveal"]]

        output = {
            "state_id": sid,
            "requested_action": requested_action,
            "candidate_count": len(group),
            "non_revealing_count": len(non_revealing),
            "candidate_scores": [
                {"gen_seed": s["gen_seed"], "reveal": s["reveal"],
                 "careful_reveal": s["careful_reveal"],
                 "compliance_score": round(s["compliance_score"], 6)}
                for s in sorted(scored, key=lambda s: s["gen_seed"])
            ],
            "selected_candidate_id": selected["gen_seed"],
            "selected_response": selected["response"],
            "selected_compliance_score": round(selected["compliance_score"], 6),
            "selected_reveal": selected["reveal"],
            # DATA_PRODUCER engineering metadata (not a scientific decision)
            "product_role": self.product_role,
            "controls_product_decision": self.controls_product_decision,
            "replacement_readiness": self.replacement_readiness,
        }
        return NativeInferenceResult(
            component_id=self.component_id, status="PASS", output=output,
            source_provenance={
                "reveal_detector": _TG_GUARD_EVAL + "::reveal",
                "careful_reveal": _TG_VALIDATE + "::careful_reveal",
                "best_of_n": _TG_GUARD_EVAL + "::pick(mode='guard') (equivalent)",
                "action_label_mapping": list(self._sci["ACTIONS"]),
            },
            asset_provenance={"action_recognizer": "model_assets/v1/tutor_guard/scientific/action_recognizer",
                              "candidate_pool": "model_assets/v1/tutor_guard/scientific/data/candidates.jsonl"},
        )

    # ---------------------------------------------------------------- metadata
    def input_requirements(self):
        return [
            {"field": "state_id", "required": True, "semantic": "frozen L3 state index (candidate pool)"},
            {"field": "requested_action", "required": True,
             "semantic": f"pedagogical action, one of {self._sci['ACTIONS'] if self._sci else ['focus','generic','probing','telling']}"},
        ]

    def training_requirements(self):
        return {
            "trainable_model": False,
            "training_inputs": [],
            "labels": [],
            "evaluation_data_fields": ["rule_hit_rate", "false_positive", "overridden_action", "downstream_outcome"],
            "product_role": self.product_role,
            "controls_product_decision": self.controls_product_decision,
            "replacement_readiness": self.replacement_readiness,
            "data_producer_contract": self.DATA_PRODUCER_CONTRACT,
        }

    def health(self):
        h = super().health()
        h.update({"product_role": self.product_role,
                  "controls_product_decision": self.controls_product_decision})
        return h
