"""StudentTwin native adapter — DATA_PRODUCER (rule-based deterministic twin state engine).

StudentTwin (StudentDigitalTwin) is a RULE-BASED deterministic state aggregator, NOT a
neural model (no checkpoint).  It ingests LearningEvents and applies a
reliability-weighted mastery update to produce a StudentState / ConceptState snapshot.

The source adapters that reference upstream components (evidence / memory / misconception /
knowledge-graph) are HEURISTIC approximations — the docstrings state "the frozen MLP requires
full online state not available at adapter scope".  The engine therefore does NOT call the
real upstream models.  learner_state and irt adapters are DEFINED but NOT used by the core
engine (available only for future product orchestration).

Single source of truth: all classes/functions are AST-extracted from
``runtime_src/v1/student_twin`` (schemas + policies + adapters + state_engine + event_store).

Scientific ontology is DIFFERENT from the product ontology; no mapping is built.
``active_product_variant = NONE``, controls_product_decision=false.
"""
import os, gc, json, hashlib, math, time, sqlite3, tempfile
from dataclasses import dataclass, field, asdict
from typing import Optional, List, Dict, Any, Tuple
import numpy as np

from .base import NativeComponentAdapter, NativeInferenceResult
from ...errors import InputValidationError, InferenceError
from ...scientific import ScientificSourceExtractor

_SRC = "student_twin/"
SOURCE_CLASS = "ORIGINAL_ARCHIVE_VERIFIED"

# extraction specs: (rel_path, [symbols]) — schemas + policies + adapters + engine + store
# (module-level constants ACTIVITY_TYPES / DEFAULT_CONFIG are extracted too)
_EXTRACT = [
    (_SRC + "schemas/models.py", ["ACTIVITY_TYPES", "LearningEvent", "EvidenceState", "ConceptState", "StudentState", "state_hash"]),
    (_SRC + "policies/policies.py", ["DEFAULT_CONFIG", "ReviewPriority", "learning_need", "review_priority", "conflict_resolution"]),
    (_SRC + "adapters/adapters.py", ["AdapterResult", "EvidenceReliabilityAdapter", "MemoryAdapter",
                                     "MisconceptionAdapter", "KnowledgeGraphAdapter", "_load_artifact"]),
    (_SRC + "state_engine/engine.py", ["StudentDigitalTwin"]),
    (_SRC + "event_store/store.py", ["SCHEMA", "EventStore"]),
]


class StudentTwinAdapter(NativeComponentAdapter):
    component_id = "student_twin"
    source_class = SOURCE_CLASS
    product_role = "DATA_PRODUCER"
    controls_product_decision = False
    replacement_readiness = "COLLECTING_DATA"

    DATA_PRODUCER_CONTRACT = [
        "event_id", "user_ref", "timestamp", "scientific_twin_state",
        "scientific_ontology", "scientific_model_version",
        "upstream_observations", "upstream_versions",
        "actual_next_behavior", "actual_next_correctness", "review_outcome", "later_learning_outcome",
    ]

    def __init__(self, config):
        super().__init__(config)
        self._ns = {}
        self._twin = None
        self._store = None
        self._db_path = None
        self._prov = {}

    def load(self):
        if self.loaded:
            return self
        ext = ScientificSourceExtractor(self.config.runtime_source_root)
        ns = {
            "json": json, "hashlib": hashlib, "math": math, "os": os, "time": time,
            "sqlite3": sqlite3, "np": np,
            "dataclass": dataclass, "field": field, "asdict": asdict,
            "Optional": Optional, "List": List, "Dict": Dict, "Any": Any, "Tuple": Tuple,
        }
        ns, prov = ext.extract_symbols(_EXTRACT, namespace=ns)
        self._ns = ns
        self._prov = prov

        # in-memory-style store (temp SQLite via the extracted EventStore; unique per instance)
        self._db_path = os.path.join(tempfile.gettempdir(), f"sdt_{os.getpid()}_{id(self)}.db")
        store = ns["EventStore"](self._db_path)

        # heuristic adapters with empty artifacts (the source adapters are heuristic;
        # the real upstream artifacts are NOT bundled, and the engine does NOT call them)
        adapters = {
            "evidence": ns["EvidenceReliabilityAdapter"](""),
            "memory": ns["MemoryAdapter"](""),
            "misconception": ns["MisconceptionAdapter"](""),
            "graph": ns["KnowledgeGraphAdapter"](""),
        }
        self._twin = ns["StudentDigitalTwin"](store, adapters)
        self._store = store
        self.loaded = True
        return self

    def unload(self):
        if self._store is not None:
            try:
                self._store.close()
            except Exception:
                pass
        if self._db_path and os.path.exists(self._db_path):
            try:
                os.remove(self._db_path)
            except Exception:
                pass
        self._twin = None
        self._store = None
        self._ns = {}
        self.loaded = False
        gc.collect()

    # ---------------------------------------------------------------- inference
    def _event(self, d):
        if not isinstance(d, dict):
            raise InputValidationError("event must be a dict")
        for k in ("event_id", "user_id", "timestamp", "activity_type", "source"):
            if k not in d:
                raise InputValidationError(f"event missing required field {k}")
        try:
            return self._ns["LearningEvent"](**{k: d[k] for k in d if k in self._ns["LearningEvent"].__dataclass_fields__})
        except (AssertionError, TypeError, ValueError) as e:
            raise InputValidationError(f"invalid event: {e}")

    def ingest_event(self, event):
        """Ingest one LearningEvent -> updated ConceptState (deterministic)."""
        if not self.loaded:
            self.load()
        ev = self._event(event)
        cs = self._twin.ingest_event(ev)
        return self._result("concept_state", {"event_id": ev.event_id, "concept_id": ev.concept_id},
                            cs.to_dict() if cs is not None else None)

    def get_state(self, user_id):
        if not self.loaded:
            self.load()
        st = self._twin.get_student_state(user_id)
        return self._result("student_state", {"user_id": user_id}, st.to_dict())

    def get_learning_need(self, user_id, concept_id):
        if not self.loaded:
            self.load()
        need = self._twin.get_learning_need(user_id, concept_id)
        return self._result("learning_need", {"user_id": user_id, "concept_id": concept_id}, {"learning_need": need})

    def replay_user(self, user_id):
        if not self.loaded:
            self.load()
        h = self._twin.replay_user(user_id)
        return self._result("replay", {"user_id": user_id}, {"state_hash": h})

    def _result(self, op, inputs, payload):
        output = {
            "operation": op,
            "inputs": inputs,
            "result": payload,
            "product_role": self.product_role,
            "controls_product_decision": self.controls_product_decision,
            "replacement_readiness": self.replacement_readiness,
            "source_class": self.source_class,
        }
        return NativeInferenceResult(component_id=self.component_id, status="PASS", output=output,
                                     source_provenance=self._prov,
                                     asset_provenance={"type": "rule-based engine (no checkpoint)"})

    # ---------------------------------------------------------------- metadata
    def input_requirements(self):
        return [
            {"field": "event", "required": True,
             "semantic": "LearningEvent (event_id, user_id, timestamp, activity_type, source, concept_id, correctness, response_time_ms, attempts, hints, ...)"},
        ]

    def training_requirements(self):
        return {
            "trainable_model": False,   # rule-based deterministic aggregator
            "inputs": "LearningEvent stream (raw interactions)",
            "labels": "none (deterministic update; no training)",
            "ontology": "product-agnostic (concept_id is an opaque string; scientific KG not bundled)",
            "unresolved": ["product ontology mapping (DIFFERENT)",
                           "upstream adapters are HEURISTIC (not real model calls)"],
        }

    def dependency_requirements(self):
        """Real scientific dependency DAG (from source)."""
        return {
            "evidence_reliability": {"classification": "SCIENTIFIC_REQUIRED", "evidence": "engine._evidence_state uses reliability weight in mastery update", "via": "HEURISTIC adapter (not frozen MLP)"},
            "memory": {"classification": "SCIENTIFIC_OPTIONAL", "evidence": "engine._apply_event uses recall on REVIEW", "via": "HEURISTIC adapter"},
            "misconception": {"classification": "SCIENTIFIC_OPTIONAL", "evidence": "engine._apply_event uses topk on incorrect", "via": "HEURISTIC adapter"},
            "knowledge_graph": {"classification": "SCIENTIFIC_OPTIONAL", "evidence": "engine._recompute_derived uses prerequisite_readiness", "via": "graph edges (NOT bundled)"},
            "learner_state": {"classification": "NOT_USED", "evidence": "adapter defined but not called by engine", "via": None},
            "irt": {"classification": "NOT_USED", "evidence": "adapter defined but not called by engine", "via": None},
        }

    def health(self):
        h = super().health()
        h.update({"product_role": self.product_role, "controls_product_decision": self.controls_product_decision,
                  "source_class": self.source_class})
        return h
