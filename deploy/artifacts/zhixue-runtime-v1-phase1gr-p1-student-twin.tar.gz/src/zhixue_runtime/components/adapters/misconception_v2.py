"""MisconceptionV2 native adapter — DATA_PRODUCER (dual-encoder + FAISS retrieval).

Faithfully wraps the scientific inference from
``runtime_src/v1/misconception_v2`` (inference.py + train_dual_encoder.py):

    (question, wrong answer) -> "question [ANS] answer" -> BGE-M3 DualEncoder (mean-pool + L2)
    -> faiss.normalize_L2 -> IndexFlatIP.search -> Top-K misconception ids

Single source of truth:
  * ``DualEncoder.encode`` (mean-pool + ``F.normalize``) is AST-extracted via
    ScientificSourceExtractor (NOT copied).
  * the query template ``"{question} [ANS] {answer}"`` is documented (inference.py:43).
  * FAISS is the real scientific backend (NOT numpy/sklearn).

Scientific ontology (2587 Eedi English misconceptions) is DIFFERENT from the product
ontology (Chinese CS/11408).  Retrieved misconception ids are WEAK labels, never ground
truth.  product_role=DATA_PRODUCER, controls_product_decision=false.
"""
import os, json, gc
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import faiss
from transformers import AutoModel, AutoTokenizer

from .base import NativeComponentAdapter, NativeInferenceResult
from ...errors import InputValidationError, InferenceError, AssetMissingError
from ...scientific import ScientificSourceExtractor

_TRAIN_SOURCE = "misconception_v2/src/retrieval/train_dual_encoder.py"
_INFERENCE_SOURCE = "misconception_v2/src/retrieval/inference.py"

SOURCE_CLASS = "ORIGINAL_ARCHIVE_VERIFIED"
QUERY_TEMPLATE = "{question} [ANS] {answer}"   # inference.py:43


class MisconceptionV2Adapter(NativeComponentAdapter):
    component_id = "misconception_v2"
    source_class = SOURCE_CLASS
    product_role = "DATA_PRODUCER"
    controls_product_decision = False
    shadow_candidate = False
    replacement_readiness = "COLLECTING_DATA"

    DATA_PRODUCER_CONTRACT = [
        "event_id", "question_reference", "answer_hash", "learner_explanation_hash",
        "query_embedding_version", "retrieved_misconception_ids", "retrieval_scores", "ranking",
        "actual_teacher_or_rule_label", "later_correction", "subsequent_retry_result", "later_mastery",
        "model_version", "ontology_version",
    ]

    def __init__(self, config):
        super().__init__(config)
        self._encoder = None        # heavy BGE-M3
        self._tokenizer = None
        self._dual = None           # extracted DualEncoder (scientific encode)
        self._index = None          # FAISS IndexFlatIP
        self._ids = []              # ontology misconception ids
        self._names = []            # ontology canonical names
        self._prov = {}

    def _asset_dir(self):
        return os.path.join(self.config.model_asset_root, "misconception_v2")

    def load(self):
        if self.loaded:
            return self
        asset = self._asset_dir()
        enc_dir = os.path.join(asset, "final_retriever", "encoder")
        index_path = os.path.join(asset, "final_retriever", "index.faiss")
        ontology_path = os.path.join(asset, "final_retriever", "ontology.json")
        for f in ("config.json", "model.safetensors", "tokenizer.json", "tokenizer_config.json"):
            if not os.path.exists(os.path.join(enc_dir, f)):
                raise AssetMissingError(f"misconception_v2 encoder missing: {enc_dir}/{f}")
        if not os.path.exists(index_path):
            raise AssetMissingError(f"misconception_v2 index missing: {index_path}")
        if not os.path.exists(ontology_path):
            raise AssetMissingError(f"misconception_v2 ontology missing: {ontology_path}")

        # scientific DualEncoder.encode (single source of truth, AST-extracted)
        ext = ScientificSourceExtractor(self.config.runtime_source_root)
        ns = {"torch": torch, "nn": nn, "F": F, "AutoTokenizer": AutoTokenizer, "AutoModel": AutoModel}
        DualEncoder, prov = ext.extract_class(_TRAIN_SOURCE, "DualEncoder", namespace=ns)
        self._dual = DualEncoder.__new__(DualEncoder)  # do NOT call __init__ (bfloat16/cuda)
        nn.Module.__init__(self._dual)
        self._tokenizer = AutoTokenizer.from_pretrained(enc_dir, local_files_only=True)
        self._encoder = AutoModel.from_pretrained(enc_dir, dtype=torch.float32, local_files_only=True).eval()
        self._dual.tok = self._tokenizer
        self._dual.model = self._encoder

        # FAISS index + ontology (real scientific assets)
        self._index = faiss.read_index(index_path)
        onto = json.load(open(ontology_path, encoding="utf-8"))
        self._ids = onto["ids"]
        self._names = onto["names"]

        # integrity: index <-> ontology alignment
        if type(self._index).__name__ != "IndexFlatIP":
            raise InferenceError(f"expected IndexFlatIP, got {type(self._index).__name__}")
        if self._index.d != 1024 or self._index.ntotal != len(self._ids):
            raise InferenceError(f"index d={self._index.d} ntotal={self._index.ntotal} != ontology {len(self._ids)}")

        self._prov = {
            "source_class": self.source_class, "source_repo": "misconception_net_v2", "source_commit": "565239a",
            "encoder_source": _TRAIN_SOURCE, "inference_source": _INFERENCE_SOURCE,
            "encode_callable": "train_dual_encoder.py::DualEncoder.encode",
            "query_template": QUERY_TEMPLATE, "query_template_line": "inference.py:43",
            "faiss_backend": "faiss-cpu 1.15.0 (IndexFlatIP)",
            "similarity": "cosine-like normalized inner product",
        }
        self.loaded = True
        return self

    def unload(self):
        self._encoder = None
        self._tokenizer = None
        self._dual = None
        self._index = None
        self._ids = []
        self._names = []
        self.loaded = False
        gc.collect()

    # ---------------------------------------------------------------- inference
    def _validate(self, question, answer, top_k):
        if not isinstance(question, str) or not question.strip():
            raise InputValidationError("question must be a non-empty string")
        if not isinstance(answer, str) or not answer.strip():
            raise InputValidationError("answer must be a non-empty string")
        if not isinstance(top_k, int) or top_k <= 0:
            raise InputValidationError("top_k must be a positive int")
        if top_k > len(self._ids):
            raise InputValidationError(f"top_k {top_k} exceeds ontology size {len(self._ids)}")
        if top_k > 100:
            raise InputValidationError("top_k exceeds runtime cap 100")

    def infer(self, question, answer, top_k=3):
        if not self.loaded:
            self.load()
        self._validate(question, answer, top_k)
        query = QUERY_TEMPLATE.format(question=question, answer=answer)

        # scientific encode (mean-pool + L2) then FAISS search (matches inference.py:45-48)
        with torch.no_grad():
            q = self._dual.encode([query], "cpu")
        q = q.cpu().numpy().astype(np.float32)
        faiss.normalize_L2(q)
        D, I = self._index.search(q, top_k)

        results = []
        for rank, (idx, score) in enumerate(zip(I[0], D[0])):
            results.append({
                "rank": rank,
                "misconception_id": self._ids[idx],
                "misconception_text": self._names[idx],
                "retrieval_score": round(float(score), 6),
            })
        if not all(np.isfinite(d) for d in D[0]):
            raise InferenceError("retrieval scores not finite")

        output = {
            "query_text": query,
            "top_k": top_k,
            "results": results,
            "score_semantics": "cosine-like normalized inner product (NOT probability)",
            "weak_label": True,   # retrieved misconception is a WEAK label, not ground truth
            "ontology_size": len(self._ids),
            "product_role": self.product_role,
            "controls_product_decision": self.controls_product_decision,
            "shadow_candidate": self.shadow_candidate,
            "replacement_readiness": self.replacement_readiness,
            "source_class": self.source_class,
        }
        return NativeInferenceResult(
            component_id=self.component_id, status="PASS", output=output,
            source_provenance=self._prov,
            asset_provenance={"encoder": "model_assets/v1/misconception_v2/final_retriever/encoder",
                              "index": "model_assets/v1/misconception_v2/final_retriever/index.faiss",
                              "ontology": "model_assets/v1/misconception_v2/final_retriever/ontology.json"},
        )

    # ---------------------------------------------------------------- metadata
    def input_requirements(self):
        return [
            {"field": "question", "required": True, "semantic": "question text"},
            {"field": "answer", "required": True, "semantic": "wrong/candidate answer (student error)"},
            {"field": "top_k", "required": False, "semantic": "number of retrieved misconceptions (default 3)"},
        ]

    def training_requirements(self):
        return {
            "trainable_model": True,
            "input": "question + wrong answer (query = 'question [ANS] answer'); ontology canonical names",
            "positives": "paired (error, true misconception)",
            "negatives": "in-batch negatives (InfoNCE) + hard negatives (retriever_hard)",
            "loss": "InfoNCE (cross_entropy over in-batch scores / temperature)",
            "hard_negatives": "retriever_hard (seed42)",
            "ontology": "Eedi misconception ontology (2587)",
            "encoder": "BGE-M3 (shared student-error / misconception encoder, mean-pool + L2, dim 1024)",
            "unresolved": ["product ontology mapping (DIFFERENT; not resolved this phase)"],
        }

    def health(self):
        h = super().health()
        h.update({"product_role": self.product_role, "controls_product_decision": self.controls_product_decision,
                  "source_class": self.source_class})
        return h
