"""EvidenceReliability native adapter — DATA_PRODUCER, VARIANT PANEL.

Wraps the scientific ReliabilityNet (self-supervised reliability scorer) from
``runtime_src/v1/evidence_reliability/evidence_reliability.py``:

    interaction features x (7 static + dynamic p_t) -> ReliabilityNet -> w in (0,1)

The scorer ``g`` is trained to down-weight unreliable observations (guesses/slips) in a
causal learner-state update ``theta <- theta + alpha * w * (y - p)``.  Output ``w`` is a
RELIABILITY WEIGHT, not a probability of correctness.

VARIANT PANEL (no arbitrary production selection): five frozen research checkpoints
(42, 42_nort, 42_surprise, 43, 44) with different feature dimensions.  The adapter loads
ALL variants and exposes them as a PANEL — it never averages, votes, or auto-selects a
winner.  ``active_product_variant = NONE``.
"""
import os, gc
import numpy as np
import torch
import torch.nn as nn

from .base import NativeComponentAdapter, NativeInferenceResult
from ...errors import InputValidationError, InferenceError, AssetMissingError
from ...scientific import ScientificSourceExtractor

_SOURCE = "evidence_reliability/evidence_reliability.py"
SOURCE_CLASS = "ORIGINAL_ARCHIVE_VERIFIED"   # recovered from working-tree snapshot (no git HEAD); layout flattened

VARIANTS = ["42", "42_nort", "42_surprise", "43", "44"]

# resolved from EVIDENCERELIABILITY_V1_FINAL_REPORT.md §6 (feature ablation)
VARIANT_DEFINITIONS = {
    "42": {"seed": 42, "n_feat": 8, "features": "all 8 (7 static + p_t)", "note": "baseline"},
    "42_nort": {"seed": 42, "n_feat": 7, "features": "drop log_rt (6 static + p_t)", "note": "no response time"},
    "42_surprise": {"seed": 42, "n_feat": 3, "features": "y, b_s, p_t (2 static + p_t)", "note": "surprise-only (IRT-surprise signal)"},
    "43": {"seed": 43, "n_feat": 8, "features": "all 8 (7 static + p_t)", "note": "baseline, seed 43"},
    "44": {"seed": 44, "n_feat": 8, "features": "all 8 (7 static + p_t)", "note": "baseline, seed 44"},
}


class EvidenceReliabilityAdapter(NativeComponentAdapter):
    component_id = "evidence_reliability"
    source_class = SOURCE_CLASS
    product_role = "DATA_PRODUCER"
    controls_product_decision = False
    variant_mode = "PANEL"
    active_product_variant = None
    replacement_readiness = "COLLECTING_DATA"

    DATA_PRODUCER_CONTRACT = [
        "event_id", "evidence_reference", "query_or_reference_context",
        "variant_id", "raw_score", "reliability_score", "predicted_class",
        "variant_disagreement", "actual_evidence_used", "human_or_manual_reliability_label",
        "downstream_answer_correctness", "later_learning_outcome", "source_quality_outcome",
        "model_version",
    ]

    def __init__(self, config):
        super().__init__(config)
        self._nets = {}       # variant_id -> (ReliabilityNet, n_feat)
        self._ReliabilityNet = None
        self._prov = {}

    def _asset_dir(self):
        return os.path.join(self.config.model_asset_root, "evidence_reliability")

    def load(self):
        if self.loaded:
            return self
        ext = ScientificSourceExtractor(self.config.runtime_source_root)
        ReliabilityNet, prov = ext.extract_class(_SOURCE, "ReliabilityNet",
                                                 namespace={"torch": torch, "nn": nn})
        self._ReliabilityNet = ReliabilityNet

        asset = self._asset_dir()
        for vid in VARIANTS:
            p = os.path.join(asset, f"reliability_net_{vid}.pt")
            if not os.path.exists(p):
                raise AssetMissingError(f"evidence_reliability checkpoint missing: {p}")
            sd = torch.load(p, map_location="cpu")
            n_feat = int(sd["net.0.weight"].shape[1])
            net = ReliabilityNet(n_feat=n_feat)
            net.load_state_dict(sd)
            net.eval()
            self._nets[vid] = (net, n_feat)

        self._prov = {
            "source_class": self.source_class, "source_repo": "evidence_reliability",
            "source_commit": "WORKING_TREE(no-git-HEAD)",
            "source": _SOURCE, "model": "ReliabilityNet (MLP 16-hidden, sigmoid output)",
            "output_semantics": "reliability weight w in (0,1) — NOT probability of correctness",
            "scientific_threshold": None,
            "variants": {vid: self._nets[vid][1] for vid in VARIANTS},
            "variant_definitions": VARIANT_DEFINITIONS,
        }
        self.loaded = True
        return self

    def unload(self):
        self._nets = {}
        self._ReliabilityNet = None
        self.loaded = False
        gc.collect()

    # ---------------------------------------------------------------- inference
    def _score(self, variant_id, features):
        net, n_feat = self._nets[variant_id]
        x = np.asarray(features, dtype=np.float32).reshape(1, -1)
        if x.shape[1] != n_feat:
            raise InputValidationError(f"variant {variant_id} expects {n_feat} features, got {x.shape[1]}")
        if not np.isfinite(x).all():
            raise InputValidationError("features contain NaN/Inf")
        with torch.no_grad():
            w = net(torch.tensor(x)).item()
        if not 0.0 < w < 1.0:
            raise InferenceError(f"variant {variant_id} weight out of (0,1): {w}")
        return float(w)

    def infer(self, features, variant_id):
        """Score ONE variant with its feature vector."""
        if not self.loaded:
            self.load()
        if variant_id not in self._nets:
            raise InputValidationError(f"unknown variant {variant_id!r}; valid={VARIANTS}")
        w = self._score(variant_id, features)
        output = {
            "variant_id": variant_id,
            "reliability_score": round(w, 6),
            "score_semantics": "reliability weight w in (0,1) — NOT probability",
            "product_role": self.product_role,
            "controls_product_decision": self.controls_product_decision,
            "variant_mode": self.variant_mode,
            "active_product_variant": self.active_product_variant,
            "replacement_readiness": self.replacement_readiness,
        }
        return NativeInferenceResult(component_id=self.component_id, status="PASS", output=output,
                                     source_provenance=self._prov,
                                     asset_provenance={"checkpoint": f"model_assets/v1/evidence_reliability/reliability_net_{variant_id}.pt"})

    def infer_panel(self, features_by_variant):
        """Score ALL variants (PANEL).  No averaging, no voting, no auto-selection."""
        if not self.loaded:
            self.load()
        if set(features_by_variant) != set(VARIANTS):
            raise InputValidationError(f"panel requires features for exactly {VARIANTS}")
        scores = {vid: round(self._score(vid, fv), 6) for vid, fv in features_by_variant.items()}
        vals = list(scores.values())
        output = {
            "variant_outputs": scores,
            "score_range": round(max(vals) - min(vals), 6),
            "score_std": round(float(np.std(vals)), 6),
            "variant_disagreement": round(float(np.std(vals)), 6),
            "averaging": False,
            "auto_selection": False,
            "active_product_variant": self.active_product_variant,
            "product_role": self.product_role,
            "controls_product_decision": self.controls_product_decision,
            "variant_mode": self.variant_mode,
            "replacement_readiness": self.replacement_readiness,
        }
        return NativeInferenceResult(component_id=self.component_id, status="PASS", output=output,
                                     source_provenance=self._prov,
                                     asset_provenance={"checkpoints": f"model_assets/v1/evidence_reliability/reliability_net_{{42,42_nort,42_surprise,43,44}}.pt"})

    # ---------------------------------------------------------------- metadata
    def input_requirements(self):
        return [
            {"field": "features", "required": True,
             "semantic": "interaction feature vector (7 static + dynamic p_t; dimension = variant n_feat)"},
            {"field": "variant_id", "required": False,
             "semantic": f"one of {VARIANTS}; omit for panel via infer_panel"},
        ]

    def training_requirements(self):
        return {
            "trainable_model": True,
            "inputs": "interaction features (y, attempt_gt1, has_bottom_hint, log_rt, hint_count, log_opp, b_s + dynamic p_t)",
            "labels": "self-supervised future-response LogLoss (NO guess/slip labels)",
            "negative_sampling": "none (reliability weighting, not classification)",
            "ontology": "N/A (learner-state reliability, not ontology-linked)",
            "encoder": "none (small MLP, hidden=16)",
            "unresolved": ["standardization stats + IRT b_map (not bundled; full pipeline requires training data)"],
        }

    def health(self):
        h = super().health()
        h.update({"product_role": self.product_role, "controls_product_decision": self.controls_product_decision,
                  "variant_mode": self.variant_mode, "active_product_variant": self.active_product_variant})
        return h
