"""Planner native adapter — DATA_PRODUCER / SHADOW CANDIDATE.

Faithfully wraps the scientific graph-greedy planner (prerequisite-constrained) from
``runtime_src/v1/planner/src/simulation/plan_sim.py``.  The scientific formulas
(``sigmoid``, ``build_graph``, ``readiness``, ``pcorr``, ``ready``) are AST-extracted at
load time (single source of truth); the 2-line graph-greedy selection (eligibility filter +
``argmax pcorr*(1-pcorr)``) is a faithful equivalent documented with source-line provenance.

This adapter does NOT control the product planner decision (research graph != product
knowledge graph).  It runs the real scientific planner to produce observations / training data.
"""
import os
from collections import defaultdict
import numpy as np

from .base import NativeComponentAdapter, NativeInferenceResult
from ...errors import InputValidationError, InferenceError
from ...scientific import ScientificSourceExtractor

_PLAN_SOURCE = "planner/src/simulation/plan_sim.py"
_FUNCS = ["sigmoid", "build_graph", "readiness", "pcorr", "ready"]

# minimal schema-valid scientific fixture (research Junyi graph data is NOT bundled;
# plan_sim.py reads it from a hardcoded /root/autodl-tmp path).  A small DAG that exercises
# the prerequisite/readiness logic: 1<-0, 2<-0, 3<-{1,2}.
_FIXTURE_EDGES = [(0, 1), (0, 2), (1, 3), (2, 3)]
_FIXTURE_N_ITEMS = 4
_FIXTURE_DIFFICULTY = {0: 0.3, 1: 0.5, 2: 0.6, 3: 0.4}


class PlannerAdapter(NativeComponentAdapter):
    component_id = "planner"
    product_role = "DATA_PRODUCER"
    controls_product_decision = False
    replacement_readiness = "COLLECTING_DATA"
    DATA_PRODUCER_CONTRACT = [
        "event_id", "learner_state_reference", "graph_context_reference",
        "scientific_candidates", "scientific_selected_node", "scientific_scores",
        "actual_product_selected_node", "learner_followed_recommendation",
        "subsequent_learning_outcome",
    ]

    def __init__(self, config):
        super().__init__(config)
        self._funcs = None
        self._ns = None
        self._prov = None
        self._adj = None

    def load(self):
        if self.loaded:
            return self
        ext = ScientificSourceExtractor(self.config.runtime_source_root)
        funcs, ns, prov = ext.extract_functions(_PLAN_SOURCE, _FUNCS)
        ns["np"] = np
        ns["defaultdict"] = defaultdict
        self._funcs, self._ns, self._prov = funcs, ns, prov
        self._adj = funcs["build_graph"](_FIXTURE_EDGES, "real", _FIXTURE_N_ITEMS, np.random.RandomState(0))
        self.loaded = True
        return self

    def unload(self):
        self._funcs = None
        self._ns = None
        self._prov = None
        self._adj = None
        self.loaded = False

    def infer(self, mastered, difficulty=None, cand=None):
        if not self.loaded:
            self.load()
        # --- validation (do not silently fix illegal scientific input) ---
        try:
            mastered = set(int(m) for m in mastered)
        except (TypeError, ValueError):
            raise InputValidationError(f"mastered must be iterable of int concept ids, got {mastered!r}")
        if any(m < 0 or m >= _FIXTURE_N_ITEMS for m in mastered):
            raise InputValidationError(f"mastered concept ids out of range [0,{_FIXTURE_N_ITEMS}): {sorted(mastered)}")
        difficulty = dict(difficulty) if difficulty is not None else dict(_FIXTURE_DIFFICULTY)
        if set(difficulty) != set(range(_FIXTURE_N_ITEMS)):
            raise InputValidationError(f"difficulty must cover concepts 0..{_FIXTURE_N_ITEMS - 1}")
        if not all(0.0 <= float(d) <= 1.0 for d in difficulty.values()):
            raise InputValidationError("difficulty values must be in [0,1]")
        cand = list(cand) if cand is not None else list(range(_FIXTURE_N_ITEMS))
        if not cand or any(int(c) < 0 or int(c) >= _FIXTURE_N_ITEMS for c in cand):
            raise InputValidationError(f"cand must be non-empty int concept ids in [0,{_FIXTURE_N_ITEMS})")

        # --- bind extracted scientific functions to the fixture state ---
        self._ns["adj"] = self._adj
        self._ns["mastered"] = mastered
        self._ns["difficulty"] = difficulty
        ready = self._funcs["ready"]
        pcorr = self._funcs["pcorr"]

        eligible = [c for c in cand if ready(c)] or list(cand)   # plan_sim.py graph_greedy branch
        selected = max(eligible, key=lambda c: pcorr(c) * (1.0 - pcorr(c)))

        scores = [{"concept": c, "eligible": bool(ready(c)),
                   "pcorr": float(pcorr(c)), "score": float(pcorr(c) * (1.0 - pcorr(c)))}
                  for c in sorted(cand)]
        output = {
            "mastered": sorted(mastered),
            "eligible_nodes": sorted([c for c in cand if ready(c)]),
            "candidate_scores": scores,
            "selected_node": selected,
            "selected_score": float(pcorr(selected) * (1.0 - pcorr(selected))),
            "product_role": self.product_role,
            "controls_product_decision": self.controls_product_decision,
            "replacement_readiness": self.replacement_readiness,
        }
        return NativeInferenceResult(
            component_id=self.component_id, status="PASS", output=output,
            source_provenance={
                "source": _PLAN_SOURCE,
                "source_sha256": self._prov["source_sha256"],
                "functions": list(_FUNCS),
                "linenos": self._prov["linenos"],
                "selection": "plan_sim.py graph_greedy branch (eligibility filter + argmax pcorr*(1-pcorr))",
                "graph": "RESEARCH_JUNYI_GRAPH (minimal schema-valid fixture)",
            },
            asset_provenance={"graph_fixture": "schema-valid DAG 1<-0, 2<-0, 3<-{1,2}"},
        )

    def input_requirements(self):
        return [
            {"field": "mastered", "required": True, "semantic": "set of mastered concept ids"},
            {"field": "difficulty", "required": False, "semantic": "concept difficulty = 1 - empirical accuracy"},
            {"field": "cand", "required": False, "semantic": "candidate concept ids (default all)"},
        ]

    def training_requirements(self):
        return {
            "trainable_model": False,
            "training_inputs": [],
            "labels": [],
            "evaluation_data_fields": ["scientific_recommendation", "actual_recommendation",
                                       "learner_behavior", "learning_outcome"],
            "product_role": self.product_role,
            "controls_product_decision": self.controls_product_decision,
            "replacement_readiness": self.replacement_readiness,
            "data_producer_contract": self.DATA_PRODUCER_CONTRACT,
        }

    def health(self):
        h = super().health()
        h.update({"product_role": self.product_role, "controls_product_decision": self.controls_product_decision})
        return h
