"""ConceptVerifier native adapter — DATA_PRODUCER / SHADOW CANDIDATE.

Wraps QuestionVerifierNet (DeBERTa-v3 cross-encoder, two heads) from
``runtime_src/v1/concept_verifier``.  The source is the ORIGINAL research repo source
(question_quality_engine), recovered byte-for-byte from the research archive.

Two DISTINCT scientific capabilities (do NOT conflate them):

  * ``concept_alignment``  — P(aligned | question, construct)  — SUPPORTED (AUROC 0.828)
      product_role=DATA_PRODUCER, shadow_candidate=true
  * ``answer_consistency`` — P(correct | question, answer)     — NOT_SUPPORTED (AUROC 0.502)
      product_role=DATA_PRODUCER, shadow_candidate=false, data_priority=MODEL_REPLACEMENT

Threshold semantics: the scientific source defines NO production threshold (AUROC evaluation).
``predicted_label = int(score >= 0.5)`` is an ENGINEERING_DEFAULT derived field, NOT a
scientifically-validated operating point.
"""
import os, json, gc
import torch
from transformers import AutoModelForSequenceClassification, AutoTokenizer

from .base import NativeComponentAdapter, NativeInferenceResult, ScientificSourceLoader
from ...errors import InputValidationError, InferenceError, AssetMissingError

_ANSWER_SOURCE = "concept_verifier/src/verifier/run_verifier.py"
_CONCEPT_SOURCE = "concept_verifier/src/verifier/run_concept_alignment.py"

# scientific input templates (run_verifier.py:103-109 answer; run_concept_alignment.py:109/141 concept)
_ANSWER_TMPL = "Question: {question} Answer: {answer}"
_CONCEPT_TMPL = "Question: {question} Concept: {concept}"

# source provenance: ORIGINAL research repo source, byte-for-byte recovered from archive
SOURCE_CLASS = "ORIGINAL_ARCHIVE_VERIFIED"

# per-capability scientific/product semantics (frozen for Backend integration)
CAPABILITIES = {
    "concept_alignment": {
        "score_semantics": "P(class_1 | Question + Concept)",
        "positive_class": "aligned",
        "scientific_threshold": None,
        "historical_support": "SUPPORTED",
        "historical_metric": "AUROC hard 0.828 +/- 0.011 (random 0.966, R@1 0.723, R@3 0.943)",
        "product_role": "DATA_PRODUCER",
        "shadow_candidate": True,
        "controls_product_decision": False,
        "replacement_readiness": "COLLECTING_DATA",
        "replacement_priority": None,
        "data_priority": None,
    },
    "answer_consistency": {
        "score_semantics": "P(class_1 | Question + Answer)",
        "positive_class": "correct/consistent",
        "scientific_threshold": None,
        "historical_support": "NOT_SUPPORTED",
        "historical_metric": "AUROC 0.5022 (approx random)",
        "product_role": "DATA_PRODUCER",
        "shadow_candidate": False,
        "controls_product_decision": False,
        "replacement_readiness": "COLLECTING_DATA",
        "replacement_priority": "HIGH",
        "data_priority": "MODEL_REPLACEMENT",
    },
}


class ConceptVerifierAdapter(NativeComponentAdapter):
    component_id = "concept_verifier"
    source_class = SOURCE_CLASS
    product_role = "DATA_PRODUCER"
    controls_product_decision = False
    replacement_readiness = "COLLECTING_DATA"
    CAPABILITIES = CAPABILITIES

    DATA_PRODUCER_CONTRACT = {
        "concept_alignment": [
            "event_id", "question_reference", "concept_reference", "score",
            "model_version", "scientific_capability", "actual_product_decision",
            "human_or_outcome_label", "later_learning_outcome",
        ],
        "answer_consistency": [
            "event_id", "question_reference", "answer_hash", "score",
            "model_version", "scientific_capability", "eventual_correctness_label",
            "teacher_or_manual_correction", "exercise_outcome", "later_learning_outcome",
        ],
    }

    def __init__(self, config):
        super().__init__(config)
        self._answer_model = None    # heavy
        self._concept_model = None   # heavy
        self._tokenizer = None
        self._predict = None         # scientific callable (run_verifier.py)
        self._score = None           # scientific callable (run_concept_alignment.py)
        self._prov = {}

    # ------------------------------------------------------------------ paths
    def _asset_dir(self):
        return os.path.join(self.config.model_asset_root, "concept_verifier")

    # -------------------------------------------------------------- load/unload
    def load(self):
        if self.loaded:
            return self
        asset = self._asset_dir()
        for sub in ("concept_head", "answer_head"):
            for f in ("config.json", "model.safetensors"):
                p = os.path.join(asset, sub, f)
                if not os.path.exists(p):
                    raise AssetMissingError(f"concept_verifier checkpoint missing: {p}")

        loader = ScientificSourceLoader(self.config.runtime_source_root)
        verifier = loader.load_module(_ANSWER_SOURCE, "_cv_run_verifier_sci")
        align = loader.load_module(_CONCEPT_SOURCE, "_cv_run_concept_alignment_sci")
        self._predict = verifier.predict
        self._score = align.score

        tok_dir = os.path.join(asset, "tokenizer")
        self._tokenizer = AutoTokenizer.from_pretrained(tok_dir, local_files_only=True)
        self._concept_model = AutoModelForSequenceClassification.from_pretrained(
            os.path.join(asset, "concept_head"), num_labels=2, dtype=torch.float32, local_files_only=True).eval()
        self._answer_model = AutoModelForSequenceClassification.from_pretrained(
            os.path.join(asset, "answer_head"), num_labels=2, dtype=torch.float32, local_files_only=True).eval()

        self._prov = {
            "source_class": self.source_class,
            "source_repo": "question_quality_engine",
            "source_commit": "a34ffdf",
            "answer_source": _ANSWER_SOURCE, "concept_source": _CONCEPT_SOURCE,
            "answer_callable": "run_verifier.py::predict", "concept_callable": "run_concept_alignment.py::score",
            "label_mapping": {0: "negative", 1: "positive"},
            "positive_class_index": 1,
            "probability": "softmax(logits)[:, 1]",
            "scientific_threshold": None,
        }
        self.loaded = True
        return self

    def unload(self):
        self._answer_model = None
        self._concept_model = None
        self._tokenizer = None
        self._predict = None
        self._score = None
        self.loaded = False
        gc.collect()

    # ---------------------------------------------------------------- inference
    def _run(self, fn, model, text):
        p = fn(model, self._tokenizer, [text], "cpu")
        return float(p[0])

    def infer_alignment(self, question, concept):
        """Capability A — concept_alignment (SUPPORTED)."""
        if not self.loaded:
            self.load()
        self._validate_text(question, "question")
        self._validate_text(concept, "concept")
        text = _CONCEPT_TMPL.format(question=question, concept=concept)
        p = self._run(self._score, self._concept_model, text)
        return self._result("concept_alignment", {"question": question, "concept": concept}, p)

    def infer_consistency(self, question, answer):
        """Capability B — answer_consistency (NOT_SUPPORTED; data collection only)."""
        if not self.loaded:
            self.load()
        self._validate_text(question, "question")
        self._validate_text(answer, "answer")
        text = _ANSWER_TMPL.format(question=question, answer=answer)
        p = self._run(self._predict, self._answer_model, text)
        return self._result("answer_consistency", {"question": question, "answer": answer}, p)

    def _validate_text(self, v, field):
        if not isinstance(v, str) or not v.strip():
            raise InputValidationError(f"{field} must be a non-empty string")

    def _result(self, capability_id, inputs, p):
        cap = self.CAPABILITIES[capability_id]
        if not 0.0 <= p <= 1.0:
            raise InferenceError(f"{capability_id} probability out of [0,1]: {p}")
        output = {
            "capability_id": capability_id,
            "inputs": inputs,
            "verification_score": round(p, 6),
            "positive_class_index": 1,
            "label_mapping": {0: "negative", 1: "positive"},
            "score_semantics": cap["score_semantics"],
            "positive_class": cap["positive_class"],
            # threshold semantics: NO scientific threshold; 0.5 is an engineering default only
            "scientific_threshold": None,
            "predicted_label": int(p >= 0.5),
            "label_is_engineering_derived": True,
            "derived_threshold": 0.5,
            "threshold_source": "ENGINEERING_DEFAULT",
            # product/data-producer semantics
            "historical_support": cap["historical_support"],
            "historical_metric": cap["historical_metric"],
            "product_role": cap["product_role"],
            "shadow_candidate": cap["shadow_candidate"],
            "controls_product_decision": cap["controls_product_decision"],
            "replacement_readiness": cap["replacement_readiness"],
            "replacement_priority": cap["replacement_priority"],
            "data_priority": cap["data_priority"],
            "source_class": self.source_class,
        }
        return NativeInferenceResult(
            component_id=self.component_id, status="PASS", output=output,
            source_provenance=self._prov,
            asset_provenance={"checkpoint": "model_assets/v1/concept_verifier/{concept_head,answer_head}",
                              "tokenizer": "model_assets/v1/concept_verifier/tokenizer"},
        )

    # ---------------------------------------------------------------- metadata
    def input_requirements(self):
        return [
            {"field": "question", "required": True, "semantic": "question text (English, Eedi-style)"},
            {"field": "concept", "required": False, "semantic": "target construct (concept_alignment capability)"},
            {"field": "answer", "required": False, "semantic": "candidate answer (answer_consistency capability)"},
        ]

    def training_requirements(self):
        return {
            "trainable_model": True,
            "model_input": "Question: {question} Concept/Answer: {x}  (text pair)",
            "training_label": "binary: 1 = aligned/correct, 0 = misaligned/wrong",
            "negative_construction": "hard negatives (same-subject different concept) + random negatives",
            "base_model": "microsoft/deberta-v3-base",
            "classifier_target": "2-class sequence classification (num_labels=2)",
            "capabilities": self.CAPABILITIES,
            "unresolved": ["answer_consistency (AUROC 0.502, NOT_SUPPORTED — needs math reasoning)"],
        }

    def health(self):
        h = super().health()
        h.update({"product_role": self.product_role, "controls_product_decision": self.controls_product_decision,
                  "source_class": self.source_class})
        return h
