import threading, time, gc
from typing import Any, Dict, Optional, Tuple

class LazyModelManager:
    """Thread-safe, fully-lazy component runtime object cache with a heavy-model slot.

    Manages component *runtime objects* (future native adapters), never scientific
    algorithms. No model/checkpoint/transformer load at construction time.
    """
    def __init__(self, heavy_slots: int = 1):
        self._lock = threading.RLock()
        self._heavy_slots = max(1, heavy_slots)
        self._cache: Dict[str, Any] = {}
        self._heavy: Dict[str, Any] = {}
        self._failures: Dict[str, dict] = {}

    def _evict_heavy(self):
        while len(self._heavy) >= self._heavy_slots:
            k = next(iter(self._heavy))
            del self._heavy[k]

    def get(self, component_id: str, loader, heavy: bool = False):
        with self._lock:
            if component_id in self._cache:
                return self._cache[component_id]
            obj = loader()
            if heavy:
                self._evict_heavy()
                self._heavy[component_id] = obj
            else:
                self._cache[component_id] = obj
            return obj

    def record_failure(self, component_id: str, exc: Exception):
        with self._lock:
            self._failures[component_id] = {
                "component_id": component_id, "exception_type": type(exc).__name__,
                "message": str(exc)[:200], "timestamp": time.time(),
            }

    def last_failure(self, component_id: str) -> Optional[dict]:
        with self._lock:
            return self._failures.get(component_id)

    def retry(self, component_id: str):
        with self._lock:
            self._failures.pop(component_id, None)
            self._cache.pop(component_id, None)
            self._heavy.pop(component_id, None)

    def unload(self, component_id: str):
        with self._lock:
            self._cache.pop(component_id, None)
            self._heavy.pop(component_id, None)
            gc.collect()

    def unload_all(self):
        with self._lock:
            self._cache.clear()
            self._heavy.clear()
            gc.collect()

    @property
    def loaded_ids(self):
        with self._lock:
            return sorted(set(self._cache) | set(self._heavy))
