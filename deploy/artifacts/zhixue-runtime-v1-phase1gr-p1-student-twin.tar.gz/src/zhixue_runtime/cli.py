import argparse, json, sys
from .config import RuntimeConfig
from .registry import ComponentRegistry
from .capability import CapabilityReport

def _config():
    return RuntimeConfig()

def main(argv=None):
    ap = argparse.ArgumentParser(prog="zhixue_runtime")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("status")
    sub.add_parser("validate")
    ap.add_argument("--json", action="store_true", dest="as_json")
    args = ap.parse_args(argv)

    cfg = _config()
    if args.cmd == "validate":
        reg = ComponentRegistry.from_home(cfg)
        r = reg.validate()
        print(json.dumps({"status": "PASS", **r}, indent=2))
        return 0
    if args.cmd == "status":
        rep = CapabilityReport(cfg)
        rows = rep.report()
        if args.as_json:
            print(json.dumps(rows, indent=2))
        else:
            print(f"{'component':24s} {'contract':10s} {'eligibility':18s} {'mode':16s} {'loadable':8s} {'blocker'}")
            for r in rows:
                bl = r["blockers"][0] if r["blockers"] else "-"
                print(f"{r['component_id']:24s} {r['contract_status']:10s} {r['product_eligibility']:18s} {r['recommended_mode']:16s} {str(r['loadable_now']):8s} {bl[:50]}")
        return 0
    return 1
