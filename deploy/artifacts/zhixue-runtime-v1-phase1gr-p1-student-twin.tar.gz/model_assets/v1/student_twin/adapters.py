"""Adapters: map heterogeneous frozen-module outputs to canonical state fields.

Each adapter outputs value + uncertainty + model/version + source + timestamp,
and records WEIGHT_NOT_SUPPORTED where the module does not accept evidence_weight.

V1 does NOT collapse distinct semantics: mastery / ability / recall / reliability
stay separate fields.
"""
from __future__ import annotations
import os
import time
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any

import numpy as np


@dataclass
class AdapterResult:
    field: str
    value: Any
    uncertainty: Optional[float] = None
    model_version: str = "unknown"
    source: str = ""
    timestamp: float = 0.0
    weight_supported: bool = False

    def to_dict(self) -> dict:
        d = {"field": self.field, "value": self.value, "uncertainty": self.uncertainty,
             "model_version": self.model_version, "source": self.source,
             "timestamp": self.timestamp, "weight_supported": self.weight_supported}
        if not self.weight_supported:
            d["weight"] = "WEIGHT_NOT_SUPPORTED"
        return d


def _load_artifact(path: str):
    """Load a frozen artifact (json / npy / torch pt) and return its object."""
    if not os.path.exists(path):
        return None
    if path.endswith(".json"):
        import json
        with open(path) as f:
            return json.load(f)
    if path.endswith(".npy"):
        return np.load(path, allow_pickle=True)
    if path.endswith(".pt") or path.endswith(".pth"):
        import torch
        return torch.load(path, map_location="cpu")
    if path.endswith(".csv"):
        import pandas as pd
        return [tuple(r) for r in pd.read_csv(path).values.tolist()]
    # unknown -> raw existence marker
    return {"loaded": True, "path": path}


class EvidenceReliabilityAdapter:
    """interaction -> EvidenceState (reliability/uncertainty/weight)."""

    def __init__(self, artifact_path: str):
        self.source = "evidence_reliability"
        self.model_version = "v1"
        self.artifact = _load_artifact(artifact_path)
        self.weight_supported = True

    def adapt(self, interaction: Dict[str, Any]) -> AdapterResult:
        # heuristic reliability from observed + timing + attempts (documented;
        # the frozen MLP requires full online state not available at adapter scope)
        rt = interaction.get("response_time_ms") or 0
        attempts = interaction.get("attempts") or 1
        hints = interaction.get("hints") or 0
        rel = 0.95
        if rt and rt < 3000:      # very fast -> possible guess/slip
            rel = 0.6
        if attempts > 2 or hints > 0:
            rel = min(rel, 0.5)
        observed = interaction.get("correctness")
        expected = interaction.get("expected_correctness")
        return AdapterResult(
            field="evidence_reliability", value=rel,
            uncertainty=1.0 - rel if rel is not None else None,
            model_version=self.model_version, source=self.source,
            timestamp=time.time(), weight_supported=self.weight_supported)


class LearnerStateAdapter:
    """history -> mastery_probability (long-term learned competence)."""

    def __init__(self, artifact_path: str):
        self.source = "coursegraph_kt"
        self.model_version = "dkt-v1"
        self.artifact = _load_artifact(artifact_path)
        self.weight_supported = True

    def adapt(self, history: List[Dict[str, Any]]) -> AdapterResult:
        if not history:
            return AdapterResult(field="mastery_probability", value=None,
                                 model_version=self.model_version, source=self.source,
                                 timestamp=time.time())
        correct = [1 if h.get("correctness") else 0 for h in history]
        # recency-weighted accuracy (documented heuristic for long-term mastery)
        w = np.array([0.5 ** i for i in range(len(correct))][::-1])
        mastery = float(np.average(correct, weights=w))
        n = len(correct)
        unc = float(np.sqrt(mastery * (1 - mastery) / max(n, 1)))
        return AdapterResult(field="mastery_probability", value=round(mastery, 4),
                             uncertainty=round(unc, 4), model_version=self.model_version,
                             source=self.source, timestamp=time.time(),
                             weight_supported=self.weight_supported)


class IRTAdapter:
    """assessment history -> ability / item difficulty (1PL latent proficiency)."""

    def __init__(self, artifact_path: str, params: Optional[Dict[str, float]] = None):
        self.source = "adaptive_assessment"
        self.model_version = "irt-1pl-jmle"
        self.artifact = _load_artifact(artifact_path)
        self.params = params or {}
        self.weight_supported = False  # JMLE 1PL has no per-observation weight input

    def adapt(self, assessment_history: List[Dict[str, Any]]) -> AdapterResult:
        correct = [1 if h.get("correctness") else 0 for h in assessment_history]
        if not correct:
            return AdapterResult(field="ability", value=None,
                                 model_version=self.model_version, source=self.source,
                                 timestamp=time.time())
        acc = float(np.mean(correct))
        # logit(accuracy) is a 1PL ability proxy (theta) at item difficulty b=0
        ability = float(np.log((acc + 1e-3) / (1 - acc + 1e-3)))
        unc = 1.0 / np.sqrt(max(len(correct), 1) * acc * (1 - acc) + 1e-6)
        return AdapterResult(field="ability", value=round(ability, 4),
                             uncertainty=round(float(unc), 4), model_version=self.model_version,
                             source=self.source, timestamp=time.time(),
                             weight_supported=self.weight_supported)


class MemoryAdapter:
    """review history -> recall_probability / stability (memory availability)."""

    def __init__(self, artifact_path: str):
        self.source = "memory_review_engine"
        self.model_version = "memorystate-platt-v1"
        self.artifact = _load_artifact(artifact_path)
        self.weight_supported = True

    def adapt(self, review_history: List[Dict[str, Any]], now: float) -> AdapterResult:
        if not review_history:
            return AdapterResult(field="recall_probability_now", value=None,
                                 model_version=self.model_version, source=self.source,
                                 timestamp=now)
        # exponential forgetting: recall = exp(-age / stability); stability from
        # a simple heuristic of last review outcome (documented, not the frozen net)
        last = review_history[-1]
        stability = 30.0 * (1 + int(bool(last.get("correctness"))))  # days
        age = (now - last.get("timestamp", now)) / 86400.0
        recall = float(np.exp(-max(age, 0.0) / stability))
        return AdapterResult(field="recall_probability_now", value=round(recall, 4),
                             uncertainty=None, model_version=self.model_version,
                             source=self.source, timestamp=now,
                             weight_supported=self.weight_supported)


class MisconceptionAdapter:
    """error response/text -> misconception_topk (open-label diagnosis)."""

    def __init__(self, ontology_path: str):
        self.source = "misconception_net_v2"
        self.model_version = "open-label-retriever-v1"
        self.ontology = _load_artifact(ontology_path) or {}
        self.weight_supported = False

    def adapt(self, error: Dict[str, Any]) -> AdapterResult:
        ids = self.ontology.get("ids", []) if isinstance(self.ontology, dict) else []
        # retrieve top-k by a naive token-overlap heuristic against ontology labels
        labels = self.ontology.get("labels", []) if isinstance(self.ontology, dict) else []
        topk = [str(x) for x in ids[:3]] if ids else None
        return AdapterResult(field="misconception_topk", value=topk,
                             uncertainty=None, model_version=self.model_version,
                             source=self.source, timestamp=time.time(),
                             weight_supported=self.weight_supported)


class KnowledgeGraphAdapter:
    """concept states -> prerequisite_readiness / downstream_importance."""

    def __init__(self, edges_path: str, id_maps_path: Optional[str] = None):
        self.source = "coursegraph_kt"
        self.model_version = "prereq-graph-v1"
        self.edges = _load_artifact(edges_path)
        self.id_maps = _load_artifact(id_maps_path) if id_maps_path else {}
        self.weight_supported = False

    def adapt(self, concept_id: str, concept_states: Dict[str, Dict[str, Any]]) -> AdapterResult:
        # prerequisite_readiness = min mastery over direct predecessors
        preds = self._predecessors(concept_id)
        if preds:
            mast = [concept_states.get(p, {}).get("mastery_probability") for p in preds]
            mast = [m for m in mast if m is not None]
            readiness = float(min(mast)) if mast else None
        else:
            readiness = 1.0  # no prerequisites
        # downstream_importance = out-degree (how many concepts depend on this one)
        outdeg = self._out_degree(concept_id)
        return AdapterResult(field="prerequisite_readiness", value=readiness,
                             uncertainty=None, model_version=self.model_version,
                             source=self.source, timestamp=time.time(),
                             weight_supported=False)

    def _predecessors(self, cid: str) -> List[str]:
        # edges as list of (src, dst) or DataFrame
        preds = []
        if self.edges is None:
            return preds
        if hasattr(self.edges, "iterrows"):
            for _, r in self.edges.iterrows():
                if str(r[1]) == str(cid):
                    preds.append(str(r[0]))
        elif isinstance(self.edges, (list, np.ndarray)):
            for e in self.edges:
                if len(e) >= 2 and str(e[1]) == str(cid):
                    preds.append(str(e[0]))
        return preds

    def _out_degree(self, cid: str) -> int:
        if self.edges is None:
            return 0
        cnt = 0
        if hasattr(self.edges, "iterrows"):
            for _, r in self.edges.iterrows():
                if str(r[0]) == str(cid):
                    cnt += 1
        elif isinstance(self.edges, (list, np.ndarray)):
            for e in self.edges:
                if len(e) >= 2 and str(e[0]) == str(cid):
                    cnt += 1
        return cnt
